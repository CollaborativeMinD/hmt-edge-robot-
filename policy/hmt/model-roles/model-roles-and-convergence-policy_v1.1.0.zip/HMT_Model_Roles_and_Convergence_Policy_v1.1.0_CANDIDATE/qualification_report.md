# Qwen-Drive-1.0 Safeguard and Qualification Report

**Evaluation time:** 2026-09-04T03:32:20Z  
**Overall disposition:** `CANDIDATE_SHADOW_HOLD_RUNTIME_AND_BYTE_SAFEGUARD`

## BLUF

The exact official Qwen-Drive model/source identities, Apache-2.0 license, critical remote LFS hashes and sizes, architecture/mode contract, output contracts, and upstream runtime profile are frozen. Exact source witnesses, policy non-widening, the integrity/output negative paths, the mode-specific command plan, the deterministic archive builder, the complete unsuppressed static suite, Fold 7, and package validation passed.

The 13.8 GB upstream model snapshot was **not** transferred into this environment. No Qwen-Drive weight loading, inference, benchmark reproduction, target-hardware measurement, road-to-forklift transfer, digital-twin campaign, HIL campaign, closed-course trial, or actuator qualification occurred. Those gates remain HOLD.

## Evidence passed

| Gate | Evidence | Result |
|---|---|---|
| Identity and provenance | Exact model/source revision locks | PASS |
| License | Exact Apache-2.0 source witness | PASS |
| Critical remote objects | Five exact LFS sizes and SHA-256 values | PASS |
| Source witness parity | Four exact Git blob identities | PASS |
| Safeguard verifier | Synthetic valid snapshot with full hash and tensor headers | PASS |
| Identity defense | Wrong snapshot revision | REJECT as required |
| Configuration defense | `num_future_points` tamper | REJECT as required |
| Completeness defense | Missing planning head | HOLD as required |
| Tensor defense | Corrupt safetensors file | REJECT as required |
| Runtime-output validator | Valid synthetic VQA/planning/BEV packet | PASS |
| Runtime-output negatives | Missing output, bad trajectory shape, and missing BEV keys | HOLD/REJECT as required |
| Mode law | SFT direct/reasoning; RL reasoning-only command plan | PASS |
| Bundle admission | Unverified model receipt | REJECT as required |
| Bundle determinism | Two synthetic safeguard tar builds | Exact SHA-256 parity |
| Policy | v1.1.0 non-widening validator | PASS |
| Complete static manifest | 9 declared, 9 executed, zero suppressions | PASS |
| Package | Root, JSON, ledger, Fold 7, debris, and receipt parity | PASS |
| Reverse RCA | Six incidents, including suite/validator dependency-cycle repair | CLOSED |

## Environmental mismatch

- Current build host: no CUDA, about 5.809 GiB RAM, Python 3.13.5.
- Upstream verified environment: Python 3.12, CUDA 12.8, bfloat16, with 24 GiB or greater GPU memory recommended.
- Hugging Face Jobs attempts: HTTP 402 before CPU or GPU job admission.
- Container download and local Hub pull paths: unavailable in this runtime.
- Docker engine: unavailable; Dockerfile/Compose path was inspected and statically retained only.

## Domain-transfer mismatch

The released BEV head targets fixed 6- or 8-camera road-driving rigs at 896×512. A forklift requires new evidence for camera geometry, calibration, indoor lighting, load occlusion, low-speed dynamics, mast/load state, mechanical-health telemetry, and command-seam behavior. This package does not admit Qwen-Drive as a forklift controller.

## Trace hashes

- Static suite: `5ab24cf97b01005f5469d5cb029aad8a2541744e78ccaf0d33f92844513be7be`
- Static tracer: `67d081eab71b41d0cf55a10aa9c865aca7f8f9db2e7072d4cc8aa379e52fc783`
- Source witness: `817ac994e09be4dc7c3ae2f516b0bad139218a1a5a3a2969ab24ebfdf1c2bd6b`
- Policy candidate: `f5cd552c667fd9acf893215b493e1b88c8bba2f8cbd984d0769c1c8e854f69bc`
- Policy validator: `f48df69035454d84c052231529ee9f255ed6eaeb95f20bca8979e2af21f13f0e`
- Package validation: `615f7e6613e21abc35e19cc032bcc6898c7d53879ccbe7a5f75465beab11333d`
- Fold 7 report: `b92506ad335484d57459067c06cb50b9abe6d5c33ac537e103e0131047b7d640`
- Cumulative Gate Ledger: `7eb138182aeb2cf84162b18c3871727c40bd919e2aa4ad90012ab39638f0c76b`
- Reverse RCA Ledger: `2edc43a757abb3da6233ea2898012697099d7f435d06f83c0927ef33db40be87`

## Next lawful action

On a connected safeguarding host, execute the revision-pinned source/model pulls, run offline full-inventory SHA-256 verification, and build the sealed model+source custody tar. Then run the official-mode SHADOW tracer on a 24 GiB-or-greater CUDA system. Only an admitted runtime-output receipt may move the model into recorded replay and domain-specific Crucible work.
