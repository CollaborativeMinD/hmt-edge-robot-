# Non-Claims

This package does not claim that the upstream model bytes were downloaded into this environment, that the complete source repository was cloned here, that Qwen-Drive inference executed here, that official benchmarks were reproduced, that the model fits the user's RTX 4070 12 GiB profile, that any quantization or offload path is valid, that road-driving results transfer to forklifts, that the fixed upstream camera geometry matches a target rig, that the model predicts mechanical health, that the model is safe for autonomous control, or that any actuator authority has been granted.

The package proves a revision lock, critical remote LFS hash inventory, source-witness identity, Apache-2.0 license preservation, policy integration, bounded verification logic, valid/tampered/missing/corrupt negative-path behavior, Docker configuration syntax, and a reproducible connected-host pull, offline verification, runtime tracer, output validation, and sealed-archive procedure.
