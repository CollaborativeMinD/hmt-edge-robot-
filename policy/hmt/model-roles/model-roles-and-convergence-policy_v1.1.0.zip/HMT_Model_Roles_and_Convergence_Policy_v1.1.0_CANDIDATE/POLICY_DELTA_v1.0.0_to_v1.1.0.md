# Policy Delta — v1.0.0 to v1.1.0

## Added

- One `embodied_multimodal_driving_specialist` role with SHADOW-only perception, VQA, and candidate-trajectory authority.
- Four Qwen-Drive mode profiles: VQA, BEV perception, SFT planning, and reasoning-only RL planning.
- Exact model/source revision locks and Apache-2.0 admission.
- Full local-byte safeguard, tensor-header, output-contract, resource, replay, Semantic Overwatch, GraphBrain, GCB, MCP+, twin, HIL, and controlled-course qualification gates.
- Explicit road-driving-to-forklift domain-transfer HOLD.
- Descendant-model identity, no-authority inheritance, SHADOW re-entry, and admitted-training-data law.
- Embodied specialist telemetry contract and current qualification state.

## Updated

- Frozen MCP reference moves from the historical 12-tool v1.0.0 reference to the current 13-tool v1.2.0 baseline.
- Baseline impact records 13 tools before and after, zero general MCP additions, and no deterministic-reducer change.
- Migration order now includes model safeguarding, mode-specific offline qualification, cross-channel evidence binding, and staged physical-domain qualification.

## Resolved integration ambiguity

The generic upstream demo can call direct and reasoning planning with the attached planner, while upstream usage guidance limits `planner-rl` to reasoning-conditioned planning. HMT applies the stricter rule: `planner-sft` for direct/reasoning, `planner-rl` for reasoning only.

## Unchanged

- LFM proposal-only orchestration ceiling.
- Granite immutable-packet semantic-review ceiling.
- Deterministic reducer behavior and exclusion of `DONE`.
- Chronos-2/Toto forecasting roles.
- NetworkX plus DuckDB graph core.
- Human Architect completion and promotion authority.

## Authority impact

`NONE`.
