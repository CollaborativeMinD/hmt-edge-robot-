"""
Unit Test Suite for Factory Orchestrator.

System Requirement:
    Provides rigorous 'Hardware-in-the-Loop' simulation to validate
    Safety Gates, PACE Logic, and Mission Critical Fault Handling.
"""

import unittest
import logging
from unittest.mock import MagicMock

# Import the system under test
# Assumes the previous code is saved as 'factory_orchestrator.py'
from factory_orchestrator import (
    FactoryOrchestrator,
    RobotState,
    SystemConfig,
    SafetyProtocol,
    VisionProtocol,
    DriverProtocol
)

class TestFactoryOrchestrator(unittest.TestCase):
    """
    Advanced Test Harness for Robotic Control Logic.
    Validates side-effects, signal integrity, and fault escalation.
    """

    def setUp(self) -> None:
        """
        Test Environment Bootstrap.
        Replaces physical hardware with instrumented Mocks.
        """
        # 1. Suppress Logging to keep test output clean
        logging.disable(logging.CRITICAL)

        # 2. create Instrumented Mocks (Spies)
        # These allow us to ask: "Was this function called?"
        self.mock_safety = MagicMock(spec=SafetyProtocol)
        self.mock_vision = MagicMock(spec=VisionProtocol)
        self.mock_driver = MagicMock(spec=DriverProtocol)

        # 3. Create Zero-Latency Config for Testing
        # Injecting this avoids the need to 'hack' the frozen class
        self.test_config = SystemConfig(
            CLOCK_CYCLE_SEC=0.0,
            BOOT_DELAY_SEC=0.0,
            SCAN_RETRY_DELAY_SEC=0.0,
            TASK_WAIT_SEC=0.0
        )

        # 4. Initialize System Under Test (SUT)
        self.xo = FactoryOrchestrator(
            safety_sys=self.mock_safety,
            vision_sys=self.mock_vision,
            hardware_sys=self.mock_driver,
            config=self.test_config
        )

    def tearDown(self) -> None:
        """Restores environment after tests."""
        logging.disable(logging.NOTSET)

    def test_boot_sequence_healthy(self) -> None:
        """
        Scenario: System Boot with all subsystems reporting Green.
        Expected: State transitions BOOT -> IDLE.
        """
        # Setup: Vision returns True (Healthy)
        self.mock_vision.health_check.return_value = True

        # Execute
        self.xo.ctx.state = RobotState.BOOT
        self.xo.run_cycle()

        # Verify
        self.assertEqual(self.xo.ctx.state, RobotState.IDLE)
        self.mock_vision.health_check.assert_called_once()

    def test_boot_sequence_failure(self) -> None:
        """
        Scenario: Vision System fails startup diagnostics.
        Expected: State transitions BOOT -> FAULT.
        """
        # Setup: Vision returns False (Unhealthy)
        self.mock_vision.health_check.return_value = False

        # Execute
        self.xo.ctx.state = RobotState.BOOT
        self.xo.run_cycle()

        # Verify
        self.assertEqual(self.xo.ctx.state, RobotState.FAULT)

    def test_mission_execution_flow(self) -> None:
        """
        Scenario: Perfect Mission (Scan -> Plan -> Execute -> Verify).
        Expected: Robot moves to target and gripper closes.
        """
        # 1. Setup State: SCANNING
        self.xo.ctx.state = RobotState.SCANNING

        # 2. Mock Vision: Returns target at (10, 10, 10)
        target = (10.0, 10.0, 10.0)
        self.mock_vision.get_grasp_coordinates.return_value = target

        # 3. Mock Safety: Approves path
        self.mock_safety.check_path.return_value = (True, target)

        # --- EXECUTE CYCLES ---

        # Cycle 1: SCANNING -> PLANNING
        self.xo.run_cycle()
        self.assertEqual(self.xo.ctx.state, RobotState.PLANNING)
        self.assertEqual(self.xo.ctx.target_coords, target)

        # Cycle 2: PLANNING -> EXECUTING
        self.xo.run_cycle()
        self.assertEqual(self.xo.ctx.state, RobotState.EXECUTING)

        # Cycle 3: EXECUTING -> VERIFYING (Check Hardware Calls)
        self.xo.run_cycle()
        self.mock_driver.move_to.assert_called_with(target)
        self.mock_driver.gripper_actuate.assert_called_with("CLOSE")
        self.assertEqual(self.xo.ctx.state, RobotState.VERIFYING)

    def test_safety_shield_rejection(self) -> None:
        """
        Scenario: Safety Controller rejects the proposed path.
        Expected: Robot aborts to IDLE, does NOT move.
        """
        self.xo.ctx.state = RobotState.PLANNING
        self.xo.ctx.target_coords = (99.0, 99.0, 99.0)

        # Safety says NO
        self.mock_safety.check_path.return_value = (False, (0, 0, 0))

        self.xo.run_cycle()

        self.assertEqual(self.xo.ctx.state, RobotState.IDLE)
        self.mock_driver.move_to.assert_not_called()

    def test_pace_catastrophic_failure(self) -> None:
        """
        Scenario: Persistent Faults trigger PACE escalation.
        Levels: Retry -> Home -> Restart -> Emergency Stop.
        """
        self.xo.ctx.state = RobotState.FAULT

        # --- LEVEL 1: PRIMARY (Retry) ---
        self.xo.run_cycle()
        self.assertEqual(self.xo.ctx.fault_counter, 1)
        self.assertEqual(self.xo.ctx.state, RobotState.IDLE)

        # Fail again
        self.xo.ctx.state = RobotState.FAULT

        # --- LEVEL 2: ALTERNATE (Home) ---
        self.xo.run_cycle()
        self.assertEqual(self.xo.ctx.fault_counter, 2)
        self.assertEqual(self.xo.ctx.state, RobotState.IDLE)
        # VERIFY: Did it actually try to go home?
        self.mock_driver.move_to.assert_called_with(self.test_config.HOME_COORDINATES)

        # Fail again
        self.xo.ctx.state = RobotState.FAULT

        # --- LEVEL 3: CONTINGENCY (Reboot) ---
        self.xo.run_cycle()
        self.assertEqual(self.xo.ctx.fault_counter, 3)
        self.assertEqual(self.xo.ctx.state, RobotState.BOOT)

        # Fail again (Catastrophic)
        self.xo.ctx.state = RobotState.FAULT

        # --- LEVEL 4: EMERGENCY (Kill) ---
        self.xo.run_cycle()
        self.assertEqual(self.xo.ctx.state, RobotState.SHUTDOWN)
        # VERIFY: Was the physical E-Stop triggered?
        self.mock_driver.emergency_stop.assert_called_once()

    def test_telemetry_schema(self) -> None:
        """
        Scenario: Request system telemetry.
        Expected: Dictionary contains all required keys for dashboard.
        """
        self.xo.ctx.state = RobotState.EXECUTING
        self.xo.ctx.fault_counter = 5

        data = self.xo.get_telemetry()

        self.assertIn("timestamp", data)
        self.assertEqual(data["state"], "EXECUTING")
        self.assertEqual(data["fault_level"], 5)
        self.assertIn("mission_active", data)

if __name__ == "__main__":
    unittest.main()
