"""
Advanced PACE Hardening Suite.

System Requirement:
    Validates non-linear failure modes, self-healing properties,
    and catastrophic cascade handling (The 'Death Spiral').
"""

import unittest
import logging
from unittest.mock import MagicMock

# Import existing system
from factory_orchestrator import (
    FactoryOrchestrator,
    RobotState,
    SystemConfig,
    SafetyProtocol,
    VisionProtocol,
    DriverProtocol
)

class TestPACEHardening(unittest.TestCase):
    """
    Edge-Case Test Harness.
    Focuses exclusively on Fault Tolerance and Recovery dynamics.
    """

    def setUp(self) -> None:
        """Initialize SUT with Zero-Latency Config."""
        logging.disable(logging.CRITICAL)

        self.mock_safety = MagicMock(spec=SafetyProtocol)
        self.mock_vision = MagicMock(spec=VisionProtocol)
        self.mock_driver = MagicMock(spec=DriverProtocol)

        # Zero-latency config for instant test execution
        self.test_config = SystemConfig(
            CLOCK_CYCLE_SEC=0.0,
            BOOT_DELAY_SEC=0.0,
            SCAN_RETRY_DELAY_SEC=0.0,
            TASK_WAIT_SEC=0.0
        )

        self.xo = FactoryOrchestrator(
            self.mock_safety,
            self.mock_vision,
            self.mock_driver,
            self.test_config
        )

    def tearDown(self) -> None:
        logging.disable(logging.NOTSET)

    def test_pace_recovery_reset(self) -> None:
        """
        Scenario: 'The Stumble'.
        System fails once (Level 1), recovers, and completes a mission.
        CRITICAL: The fault counter MUST reset to 0 after success.
        """
        # 1. Induce Level 1 Fault
        self.xo.ctx.state = RobotState.FAULT
        self.xo.run_cycle() # Executes PACE 1 -> Goes to IDLE
        self.assertEqual(self.xo.ctx.fault_counter, 1)
        self.assertEqual(self.xo.ctx.state, RobotState.IDLE)

        # 2. Run a Perfect Mission
        # IDLE -> SCANNING
        self.xo.run_cycle() # Auto-triggers SCANNING
        self.xo.ctx.state = RobotState.SCANNING # Auto-trigger logic

        # SCANNING -> PLANNING
        self.mock_vision.get_grasp_coordinates.return_value = (10.0, 10.0, 10.0)
        self.xo.run_cycle()

        # PLANNING -> EXECUTING
        self.mock_safety.check_path.return_value = (True, (10.0, 10.0, 10.0))
        self.xo.run_cycle()

        # EXECUTING -> VERIFYING
        self.xo.run_cycle()

        # VERIFYING -> IDLE (Success)
        self.xo.run_cycle()

        # 3. Assert Anxiety Reset
        # If this fails, the robot remembers old trauma and will prematurely E-Stop later.
        self.assertEqual(self.xo.ctx.fault_counter, 0)

    def test_contingency_boot_loop_prevention(self) -> None:
        """
        Scenario: 'The Death Spiral'.
        PACE Level 3 triggers a Reboot.
        The Reboot fails (Vision is dead).
        System must NOT loop back to Boot; it must escalate to Level 4 (Shutdown).
        """
        # 1. Fast forward to Level 3 (Contingency: Reboot)
        self.xo.ctx.fault_counter = 2
        self.xo.ctx.state = RobotState.FAULT

        self.xo.run_cycle() # Executes PACE 3
        self.assertEqual(self.xo.ctx.state, RobotState.BOOT)
        self.assertEqual(self.xo.ctx.fault_counter, 3)

        # 2. Simulate Broken Hardware during Boot
        self.mock_vision.health_check.return_value = False

        self.xo.run_cycle() # Executes Boot -> Fails -> Goes to FAULT
        self.assertEqual(self.xo.ctx.state, RobotState.FAULT)

        # 3. Next Cycle: Must recognize persistence and kill power
        self.xo.run_cycle() # Executes PACE 4

        self.assertEqual(self.xo.ctx.state, RobotState.SHUTDOWN)
        self.mock_driver.emergency_stop.assert_called_once()

    def test_intermittent_glitch_handling(self) -> None:
        """
        Scenario: 'The Flaky Cable'.
        Fault 1 occurs. Recover. 
        Later, Fault 1 occurs again.
        Expected: The second fault is treated as Level 1 (Retry), NOT Level 2 (Home).
        """
        # Glitch 1
        self.xo.ctx.state = RobotState.FAULT
        self.xo.run_cycle() # PACE 1
        self.assertEqual(self.xo.ctx.fault_counter, 1)

        # Success Cycle (Resets counter)
        self.xo.ctx.state = RobotState.VERIFYING
        self.xo.run_cycle()
        self.assertEqual(self.xo.ctx.fault_counter, 0)

        # Glitch 2 (Hours later...)
        self.xo.ctx.state = RobotState.FAULT
        self.xo.run_cycle()

        # Assertion: Should be Level 1 again, not Level 2
        self.assertEqual(self.xo.ctx.fault_counter, 1)
        self.mock_driver.move_to.assert_not_called() # Should not have homed

    def test_safety_persistent_rejection(self) -> None:
        """
        Scenario: Safety Layer persistently rejects movement.
        The system logic currently sends rejected paths to IDLE.
        If we want safety rejections to trigger faults, we'd need to change logic.
        Currently, this tests that Safety Rejection is NOT treated as a PACE Fault.
        """
        self.xo.ctx.state = RobotState.PLANNING
        self.xo.ctx.target_coords = (100.0, 100.0, 100.0)
        self.mock_safety.check_path.return_value = (False, (0,0,0))

        self.xo.run_cycle()

        self.assertEqual(self.xo.ctx.state, RobotState.IDLE)
        # Verify PACE was NOT triggered
        self.assertEqual(self.xo.ctx.fault_counter, 0)

if __name__ == "__main__":
    unittest.main()
