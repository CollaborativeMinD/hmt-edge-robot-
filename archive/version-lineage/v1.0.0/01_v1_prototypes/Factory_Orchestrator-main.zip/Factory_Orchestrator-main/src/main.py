"""
Main Entry Point for the Factory Orchestration System.

System Requirement:
    Initializes Hardware Adapters, injects dependencies into the
    Orchestrator, and maintains the primary mission loop.
"""

import sys
import logging
from factory_orchestrator import FactoryOrchestrator, SystemConfig
from hardware_adapters import HaloSafeAdapter, NeuroVisionAdapter, IndustrialArmAdapter

def main():
    """
    Boot sequence and main execution loop.
    """
    # 1. Setup Logging
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger("Main")

    logger.info(">>> BOOTING PRODUCTION SYSTEM <<<")

    # 2. Instantiate Adapters (The Real Hardware)
    # This is the "Critical Path". If this fails, we cannot proceed.
    try:
        real_safety = HaloSafeAdapter(ip_address="192.168.1.50")
        real_vision = NeuroVisionAdapter(port="/dev/ttyUSB0")
        real_robot = IndustrialArmAdapter(controller_ip="192.168.1.100")

    except Exception as error_context:  # pylint: disable=broad-exception-caught
        # SAFETY CRITICAL: Catch ALL errors during hardware init.
        # If we miss a specific vendor error, the robot might start
        # partially initialized, which is dangerous.
        logger.critical("HARDWARE INITIALIZATION FAILED: %s", error_context)
        sys.exit(1)  # Signal OS that startup failed

    # 3. Configure Orchestrator
    # We can tune the timings for the real world here
    prod_config = SystemConfig(
        CLOCK_CYCLE_SEC=0.1,    # 10Hz Control Loop
        BOOT_DELAY_SEC=2.0,     # Give hardware time to warm up
        MAX_RETRY_ATTEMPTS=3
    )

    # 4. Inject Dependencies
    xo = FactoryOrchestrator(
        safety_sys=real_safety,
        vision_sys=real_vision,
        hardware_sys=real_robot,
        config=prod_config
    )

    # 5. Run Mission
    logger.info(">>> SYSTEM LIVE. ENTERING AUTONOMOUS MODE. <<<")
    try:
        while True:
            xo.run_cycle()

            # Optional: Telemetry Heartbeat
            # data = xo.get_telemetry()
            # send_to_dashboard(data)

    except KeyboardInterrupt:
        logger.info(">>> OPERATOR SHUTDOWN <<<")
        real_robot.emergency_stop()  # Safety first!
        sys.exit(0)

if __name__ == "__main__":
    main()
