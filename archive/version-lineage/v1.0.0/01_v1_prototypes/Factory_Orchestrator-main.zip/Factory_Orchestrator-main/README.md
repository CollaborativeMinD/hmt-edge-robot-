# Factory Orchestrator: PACE-Based Robotic Control

![Status](https://img.shields.io/badge/Status-Active-brightgreen)
[![Factory Orchestrator CI](https://github.com/CollaborativeMinD/Factory_Orchestrator/actions/workflows/ci_pipeline.yml/badge.svg)](https://github.com/CollaborativeMinD/Factory_Orchestrator/actions/workflows/ci_pipeline.yml)
![Pylint](https://img.shields.io/badge/Pylint-10.00%2F10-brightgreen)
![Tests](https://img.shields.io/badge/Unit_Tests-10%2F10_Passing-brightgreen)
![License](https://img.shields.io/badge/License-MIT-blue)

**Factory Orchestrator** is a mission-critical robotic control architecture designed to decouple high-level mission logic from hardware-specific drivers. It utilizes a **Finite State Machine (FSM)** and the **Adapter Pattern** to achieve 100% deterministic execution and vendor agnosticism for industrial Raspberry Pi 5 deployments.

---

## 📊 Operational Telemetry & Validation
*Visual verification of the PACE logic core and the autonomous state machine transitions.*

| **Standard Mission Loop** | **PACE Hardening Suite** | **Logic Core Verification** |
| :---: | :---: | :---: |
| ![Mission Loop](tests/the_mission_loop.png) | ![Hardening Set](tests/hardening_set.png) | ![Basic Set](tests/basic_set.png) |
| **Status:** ✅ Cycle Complete | **Status:** ✅ Recovery Verified | **Status:** ✅ 10/10 Passing |

---

## 🛡️ The PACE Fault Strategy
To prevent catastrophic hardware damage, the system implements a self-healing **PACE** plan that escalates through four levels of intervention:

| Level | Name | Trigger | System Requirement |
| :--- | :--- | :--- | :--- |
| **1** | **Primary** | First Fault | **Retry:** Resets context state to `IDLE` for immediate re-attempt. |
| **2** | **Alternate** | Second Fault | **Retreat:** Moves arm to safe `HOME_COORDINATES` to prevent collision. |
| **3** | **Contingency** | Third Fault | **Reboot:** Executes soft-reboot of Vision and Safety software layers. |
| **4** | **Emergency** | Fourth Fault | **Kill:** Triggers hardware E-Stop and forces OS-level process exit. |

*Note: A successful mission cycle automatically triggers the `_handle_verification` state, resetting the `fault_counter` to 0 (Self-Healing).*

---

## 🏗 System Architecture

The system is divided into three distinct layers to maximize testability and safety:

### 1. The Core (Logic Layer)
* **File:** `src/factory_orchestrator.py`
* **Responsibility:** Manages the State Machine, enforces Safety Gates, and executes the PACE plan.

### 2. The Protocols (Interface Layer)
* **Responsibility:** Abstract Base Classes (Python `Protocol`) defining the "Contract" between the brain and the body.
* **Components:** `SafetyProtocol`, `VisionProtocol`, `DriverProtocol`.

### 3. The Adapters (Hardware Layer / HAL)
* **File:** `src/hardware_adapters.py`
* **Responsibility:** Translates system commands into messy, proprietary vendor SDK calls (e.g., Fanuc, Kuka, or Raspberry Pi GPIO).

---

## 🎮 Usage & Simulation

### 1. Simulation Mode (Logic Verification)
To run the logic core against Mock Interfaces (Hardware-in-the-Loop simulation):

```bash
# Run the core orchestrator with Mock drivers
python src/factory_orchestrator.py

```

### 2. Production Mode (Pi 5 Deployment)

To run the system with real hardware adapters enabled:

```bash
# Initialize real hardware and enter autonomous loop
python src/main.py

```

### 3. Verification Suite

The system includes `test_hardening_factory_orchestrator.py`, covering:

1. **Self-Healing Logic:** Verifying fault counter resets after mission success.
2. **Death Spiral Prevention:** Ensuring failed reboots escalate to Emergency Stop.
3. **Intermittent Glitch Handling:** Testing resilience against flapping signals.

```bash
python -m unittest discover tests -v

```

---

## 📂 Project Structure

```text
Factory_Orchestrator/
│
├── .github/workflows/
│   └── ci_pipeline.yml       # Automated Build & Test Badge
│
├── src/
│   ├── __init__.py           # Package marker
│   ├── factory_orchestrator.py   # The "Brain" (FSM & PACE Logic)
│   ├── hardware_adapters.py      # The "Body" (Hardware Abstraction Layer)
│   └── main.py                   # Production Entry Point
│
├── tests/
│   ├── __init__.py           # Package marker
│   ├── test_factory_orchestrator.py
│   ├── test_hardening_factory_orchestrator.py
│   ├── basic_set.png             # Telemetry Asset
│   ├── hardening_set.png         # Telemetry Asset
│   └── the_mission_loop.png      # Telemetry Asset
│
└── requirements.txt              # System Dependencies

```

---

**Author:** Charles Austin II (Principal Solutions Architect)

*Focus: Robotics Architecture, Fault-Tolerant Systems, and Industrial HAL Design.*
