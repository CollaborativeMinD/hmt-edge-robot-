# 🛡️ HaloSafe: ISO 15066 Safety Controller

![Status](https://img.shields.io/badge/Status-Active-brightgreen)
![Pylint](https://img.shields.io/badge/Pylint-10.00%2F10-brightgreen)
![Tests](https://img.shields.io/badge/Unit_Tests-11%2F11_Passing-brightgreen)
![License](https://img.shields.io/badge/License-MIT-blue)

**HaloSafe** is a high-integrity safety monitoring layer designed for collaborative robots (cobots). It implements **Speed and Separation Monitoring (SSM)** according to **ISO/TS 15066** standards, serving as a "Man-in-the-Middle" compliance guard between motion planners and robot hardware.

## 📊 Safety Telemetry Dashboard (ISO 15066)
*Real-time telemetry captured from the Admittance Controller during verified verification runs.*

| 🟢 STATE: SAFE | 🟡 STATE: WARN | 🔴 STATE: STOP |
| :---: | :---: | :---: |
| ![Safe State](SAFE_State.png) ![safe_state](safe_state.png) | ![Warn State](WARN_State.png) ![warn_state](warn_state.png) | ![Stop State](STOP_State.png) ![stop_state](stop_state.png) |
| **Logic:** `Dist > max_dist` | **Logic:** `max > Dist > min` | **Logic:** `Dist < min_dist` |
| **Action:** Full Velocity (100%) | **Action:** Dynamic Scaling | **Action:** Protective Stop (0%) |

---

## 🏗️ System Architecture

The system is architected as a closed-loop control system with a dedicated safety supervisor.

### 1. Admittance Controller (The Physics)
* **Role:** Simulates a **Mass-Spring-Damper** system ($M\ddot{x} + D\dot{x} + Kx = F_{ext}$).
* **Function:** Gives the robot "virtual weight," rendering it compliant to external forces (collisions) rather than rigid.
* **Config:** Managed via immutable `PhysicsConfig` dataclasses.

### 2. Safety Monitor (The Watchdog)
* **Role:** Implements the deterministic safety gates required by ISO 15066.
* **Logic:**
    * **Green Zone (> 2.0m):** 100% Velocity.
    * **Yellow Zone (0.5m - 2.0m):** Linear velocity scaling ($v_{safe} = v_{cmd} \times \alpha$).
    * **Red Zone (< 0.5m):** Hard Protective Stop (0% Velocity).

---

## ✅ Quality Assurance & Verification
This repository adheres to strict Systems Engineering software standards to ensure reliability in safety-critical contexts.

| Metric | Status | Standard |
| :--- | :--- | :--- |
| **Static Analysis** | `10.00/10` | **Pylint** (PEP 8 Strict) |
| **Unit Testing** | `11/11 PASSED` | **unittest** (Physics & Logic Coverage) |
| **Runtime Safety** | **ACTIVE** | Pre-flight Self-Checks on Boot |
| **Architecture** | **PACE** | Primary, Alternate, Contingency, Emergency Handling |

### Verification Protocol
The system includes a rigorous test suite (`test_safety_controller.py`) that validates:
1.  **Physics Integrity:** Verifies $F=ma$ calculations and damping effects.
2.  **Boundary Analysis:** Tests exact edge cases at 0.5m (Stop) and 2.0m (Free Run).
3.  **Fail-Safe Logic:** Ensures system defaults to STOP state on invalid inputs.

---

## 🚀 Usage

### 1. Run the Simulation
Launch the dashboard with real-time ASCII visualization:
```bash
python safety_controller.py

```

*Note: The system performs a self-diagnostic pre-check before initializing the physics engine.*

### 2. Run the Verification Suite

Execute the full unit test battery:

```bash
python test_safety_controller.py

```

## 🛠️ Configuration

System parameters are managed via frozen Dataclasses to prevent runtime mutation.

```python
@dataclass(frozen=True)
class PhysicsConfig:
    mass: float = 5.0          # Virtual Mass (kg)
    damping: float = 10.0      # Virtual Damping (Ns/m)

@dataclass(frozen=True)
class SafetyConfig:
    min_dist: float = 0.5      # Red Zone: Protective Stop (m)
    max_dist: float = 2.0      # Green Zone: Full Speed (m)

```

## 📦 Dependencies

* **Python 3.10+** (Required for Dataclasses)
* **NumPy** (Vector Math)

---

**Author:** Charles Austin (Senior Systems Architect Refactor)
*Focus: Robotics Safety Systems, Human-Robot Interaction (HRI), Model-Based Systems Engineering*
