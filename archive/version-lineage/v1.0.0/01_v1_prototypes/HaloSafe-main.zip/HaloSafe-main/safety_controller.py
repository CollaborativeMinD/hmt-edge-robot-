"""
HaloSafe: ISO 15066 Safety Controller Implementation.

A high-integrity refactor of the HaloSafe system, implementing an Admittance Control
scheme and Speed & Separation Monitoring (SSM) for Human-Robot Interaction.

Architecture:
    - Model: AdmittanceController (Physics), SafetyMonitor (Logic)
    - View: DashboardView (ASCII UI)
    - Controller: SimulationEngine (Orchestration)

Author: Senior Systems Architect (Refactored)
Original Author: Charles Austin
"""

# --- CELL 1: IMPORTS & CONFIGURATION ---
import sys
import time
import math
import logging
import unittest
from dataclasses import dataclass
from typing import Tuple, Optional, Final
import numpy as np

# Configure System Logging
logging.basicConfig(level=logging.ERROR)
LOGGER = logging.getLogger(__name__)

@dataclass(frozen=True)
class PhysicsConfig:
    """Configuration constants for the Admittance Controller."""
    mass: float = 5.0          # Virtual Mass (kg)
    damping: float = 10.0      # Virtual Damping (Ns/m)
    stiffness: float = 0.0     # Virtual Stiffness (N/m)
    dt: float = 0.05           # Cycle time (s)

@dataclass(frozen=True)
class SafetyConfig:
    """Configuration constants for ISO 15066 Safety Zones."""
    min_dist: float = 0.5      # Red Zone: Protective Stop (m)
    max_dist: float = 2.0      # Green Zone: Full Speed (m)

@dataclass(frozen=True)
class SimConfig:
    """Simulation environment parameters."""
    human_avg_dist: float = 1.7
    human_move_amp: float = 1.3
    human_move_freq: float = 0.4
    input_force_x: float = 15.0

# --- CELL 2: CLASS DEFINITIONS & LOGIC ---

class AdmittanceController:
    """
    Implements a Mass-Spring-Damper system to render the robot compliant.
    Equation: M*x_dd + D*x_d + K*(x - x_ref) = F_ext
    """

    def __init__(self, config: PhysicsConfig) -> None:
        """
        Initialize the controller with physics constants.

        Args:
            config (PhysicsConfig): The immutable configuration object.

        Raises:
            ValueError: If mass is <= 0 (Singularity risk).
        """
        if config.mass <= 0:
            raise ValueError("System Fault: Virtual Mass must be positive.")

        self.cfg = config

        # System State
        self.position: np.ndarray = np.zeros(3)
        self.velocity: np.ndarray = np.zeros(3)

    def reset_state(self) -> None:
        """Resets the internal integrator state to zero."""
        self.position = np.zeros(3)
        self.velocity = np.zeros(3)

    def step(
        self,
        external_force: np.ndarray,
        reference_position: Optional[np.ndarray] = None
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Advance the physics simulation by one time step (Euler Integration).

        Args:
            external_force (np.ndarray): 3D force vector applied to the robot.
            reference_position (Optional[np.ndarray]): The 'zero' point for the spring.
                                                     Defaults to current position.

        Returns:
            Tuple[np.ndarray, np.ndarray]: Updated (Position, Velocity) vectors.
        """
        # Alternate Path: If no reference provided, assume neutral position
        if reference_position is None:
            reference_position = self.position

        # 1. Calculate internal dynamics forces
        damping_force = self.cfg.damping * self.velocity
        spring_force = self.cfg.stiffness * (self.position - reference_position)

        # 2. Solve for Acceleration (Newton's 2nd Law)
        # a = (F_ext - F_damp - F_spring) / M
        acceleration = (external_force - damping_force - spring_force) / self.cfg.mass

        # 3. Integrate State (Euler Method)
        self.velocity += acceleration * self.cfg.dt
        self.position += self.velocity * self.cfg.dt

        return self.position, self.velocity


class SafetyMonitor:
    """
    ISO 15066 Speed and Separation Monitoring (SSM) Logic.
    Acts as a watchdog to scale velocity based on human proximity.
    """

    def __init__(self, config: SafetyConfig) -> None:
        """
        Initialize the safety monitor zones.

        Raises:
            ValueError: If Red Zone distance >= Green Zone distance.
        """
        if config.min_dist >= config.max_dist:
            raise ValueError("Safety Config Error: Red Zone must be smaller than Green Zone.")

        self.cfg = config
        self._last_scale_factor: float = 1.0

    @property
    def is_emergency_stop(self) -> bool:
        """Returns True if the system is currently in a protective stop state."""
        return self._last_scale_factor == 0.0

    def calculate_scaling_factor(self, robot_pos: np.ndarray, human_pos: np.ndarray) -> float:
        """
        Compute the velocity scaling factor (0.0 to 1.0).

        Args:
            robot_pos (np.ndarray): 3D coordinates of Robot TCP.
            human_pos (np.ndarray): 3D coordinates of Human Operator.

        Returns:
            float: 0.0 (Stop), 0.0-1.0 (Scale), 1.0 (Full Speed).
        """
        # Contingency: Ensure inputs are numpy arrays
        if not isinstance(robot_pos, np.ndarray) or not isinstance(human_pos, np.ndarray):
            LOGGER.error("Invalid input types for position vectors.")
            self._last_scale_factor = 0.0
            return 0.0

        distance = np.linalg.norm(robot_pos - human_pos)

        # Zone Logic
        if distance < self.cfg.min_dist:
            scale = 0.0  # Protective Stop
        elif distance > self.cfg.max_dist:
            scale = 1.0  # Free Run
        else:
            # Linear Interpolation between zones
            denom = self.cfg.max_dist - self.cfg.min_dist
            scale = (distance - self.cfg.min_dist) / denom
            scale = float(np.clip(scale, 0.0, 1.0))

        self._last_scale_factor = scale
        return scale


class DashboardView:
    """Handles CLI visualization to keep logic pure."""

    BAR_LENGTH: Final[int] = 25

    @staticmethod
    def display_banner(version: str) -> None:
        """
        Prints the system startup header to the console.

        Args:
            version (str): Version string to display.
        """
        print(f"\n--- HALOSAFE: ACTIVE SAFETY MONITOR {version} ---")
        print("  [SYSTEM ONLINE]")
        print("  [MODE: ISO 15066 Speed & Separation Monitoring]")
        print("-" * 75)

    @staticmethod
    def render(human_dist: float, scale: float, robot_vel: float) -> None:
        """
        Prints the real-time status line.
        """
        filled = int(DashboardView.BAR_LENGTH * scale)
        progress_bar = "█" * filled + "░" * (DashboardView.BAR_LENGTH - filled)

        if scale >= 0.8:
            status = "🟢 SAFE"
        elif scale >= 0.2:
            status = "🟡 WARN"
        else:
            status = "🔴 STOP"

        # \r allows overwriting the line
        sys.stdout.write(
            f"\r[HUMAN DIST: {human_dist:.2f}m] "
            f"[{progress_bar}] {int(scale*100):3d}% MAX SPD "
            f"| {status} "
            f"| ROBOT VEL: {robot_vel:.3f} m/s"
        )
        sys.stdout.flush()


# --- CELL 3: UNIT TESTS ---

class TestSafetySystem(unittest.TestCase):
    """Verifies core safety logic before simulation start."""

    def setUp(self):
        self.safe_cfg = SafetyConfig(min_dist=0.5, max_dist=2.0)
        self.monitor = SafetyMonitor(self.safe_cfg)
        self.robot_pos = np.zeros(3)

    def test_protective_stop(self):
        """Test that robot stops when human is too close."""
        human_pos = np.array([0.4, 0, 0])  # Inside 0.5m limit
        scale = self.monitor.calculate_scaling_factor(self.robot_pos, human_pos)
        self.assertEqual(scale, 0.0, "Robot did not stop in Red Zone")
        self.assertTrue(self.monitor.is_emergency_stop)

    def test_full_speed(self):
        """Test that robot runs full speed when human is far."""
        human_pos = np.array([2.5, 0, 0])  # Outside 2.0m limit
        scale = self.monitor.calculate_scaling_factor(self.robot_pos, human_pos)
        self.assertEqual(scale, 1.0, "Robot not at full speed in Green Zone")

    def test_scaling(self):
        """Test linear scaling in Yellow Zone."""
        # Midpoint calculation: 0.5 start, 2.0 end. Midpoint is 1.25
        human_pos = np.array([1.25, 0, 0])
        scale = self.monitor.calculate_scaling_factor(self.robot_pos, human_pos)
        self.assertAlmostEqual(scale, 0.5, places=2)


# --- CELL 4: MISSION EXECUTION ---

class SimulationEngine:
    """Orchestrates the main application loop."""

    def __init__(self) -> None:
        self.phys_config = PhysicsConfig()
        self.safe_config = SafetyConfig()
        self.sim_config = SimConfig()

        self.controller = AdmittanceController(self.phys_config)
        self.monitor = SafetyMonitor(self.safe_config)

    def shutdown(self, reason: str = "Operator Request") -> None:
        """
        Handles the safe termination of the simulation.

        Args:
            reason (str): Description of why the system is shutting down.
        """
        print(f"\n\n[SYSTEM SHUTDOWN] {reason}")

    def run(self) -> None:
        """Executes the simulation loop."""
        DashboardView.display_banner("v2.2")

        sim_time = 0.0

        try:
            while True:
                # 1. Update Environment (Simulate Human Motion)
                # Calculates simulated human distance using a sine wave
                sine_val = math.sin(sim_time * self.sim_config.human_move_freq)
                human_dist = (
                    self.sim_config.human_avg_dist +
                    self.sim_config.human_move_amp * sine_val
                )

                # 2. Safety Monitor Logic
                human_pos_vector = np.array([human_dist, 0.0, 0.0])
                robot_pos_vector = np.zeros(3)  # Simplified robot pos

                safety_scale = self.monitor.calculate_scaling_factor(
                    robot_pos_vector, human_pos_vector
                )

                # 3. Physics Step
                input_force = np.array([self.sim_config.input_force_x, 0.0, 0.0])
                _, raw_velocity = self.controller.step(external_force=input_force)

                # 4. Actuation (Apply Safety Limits)
                safe_velocity_x = raw_velocity[0] * safety_scale

                # 5. Visualization
                DashboardView.render(human_dist, safety_scale, safe_velocity_x)

                # Rate Limiting
                time.sleep(self.phys_config.dt)
                sim_time += self.phys_config.dt

        except KeyboardInterrupt:
            self.shutdown("Operator Request")
        # pylint: disable=broad-exception-caught
        except Exception as err:
            LOGGER.critical("Emergency Shutdown: %s", err, exc_info=True)
            self.shutdown(f"System halted: {err}")
            sys.exit(1)

if __name__ == "__main__":
    # 1. Run Pre-flight Checks (Unit Tests)
    loader = unittest.TestLoader()
    suite = loader.loadTestsFromTestCase(TestSafetySystem)
    runner = unittest.TextTestRunner(verbosity=0)  # verbosity 0 to keep CLI clean
    result = runner.run(suite)

    if not result.wasSuccessful():
        print("Pre-flight Self-Check Failed. Aborting.")
        sys.exit(1)

    # 2. Launch Mission
    engine = SimulationEngine()
    engine.run()
