"""
Unit Test Suite for HaloSafe Safety Controller.
TOTAL TESTS: 11

This module provides comprehensive coverage for:
1. Admittance Control Physics (Mass-Spring-Damper logic) [5 Tests]
2. ISO 15066 Safety Monitoring (Zone logic and scaling)  [6 Tests]
3. System Configuration Validation

Target Pylint Score: 10.0/10
"""

import unittest
import logging
import numpy as np

# Ensure this import matches your filename (safety_controller.py)
from safety_controller import (
    AdmittanceController,
    SafetyMonitor,
    PhysicsConfig,
    SafetyConfig
)


class TestAdmittancePhysics(unittest.TestCase):
    """Verifies the physics engine and compliance logic (5 Tests)."""

    def setUp(self) -> None:
        """Initialize a standard controller before each test."""
        self.config = PhysicsConfig(mass=10.0, damping=5.0, stiffness=0.0, dt=0.1)
        self.controller = AdmittanceController(self.config)

    def test_initialization_state(self) -> None:
        """Ensure robot starts at zero velocity and position."""
        np.testing.assert_array_equal(self.controller.position, np.zeros(3))
        np.testing.assert_array_equal(self.controller.velocity, np.zeros(3))

    def test_invalid_mass_raises_error(self) -> None:
        """Verify that zero or negative mass raises a ValueError."""
        invalid_cfg = PhysicsConfig(mass=0.0)
        with self.assertRaises(ValueError):
            AdmittanceController(invalid_cfg)

    def test_step_mechanics(self) -> None:
        """
        Verify that applying force causes acceleration and velocity change.
        F = ma -> a = F/m.
        Force = 10N, Mass = 10kg -> Accel = 1 m/s^2.
        dt = 0.1s -> Vel change = 0.1 m/s.
        """
        force_input = np.array([10.0, 0.0, 0.0])
        
        # Step 1
        pos, vel = self.controller.step(external_force=force_input)
        
        # Expected Velocity: 0 + (10/10 * 0.1) = 0.1
        expected_vel_x = 0.1
        
        # We use AlmostEqual for floating point comparisons
        self.assertAlmostEqual(vel[0], expected_vel_x, places=5)
        
        # Expected Position: 0 + (0.1 * 0.1) = 0.01 (Euler integration)
        self.assertAlmostEqual(pos[0], 0.01, places=5)

    def test_damping_effect(self) -> None:
        """Verify that damping reduces acceleration over time."""
        # Inject initial velocity
        self.controller.velocity = np.array([1.0, 0.0, 0.0])
        
        # Apply ZERO force. Damping should slow it down.
        # F_net = -D*v = -5.0 * 1.0 = -5.0 N
        # a = -5.0 / 10.0 = -0.5 m/s^2
        # new_v = 1.0 + (-0.5 * 0.1) = 0.95
        
        zero_force = np.zeros(3)
        _, vel = self.controller.step(external_force=zero_force)
        
        self.assertLess(vel[0], 1.0, "Velocity did not decrease due to damping")
        self.assertAlmostEqual(vel[0], 0.95, places=5)

    def test_reset_state(self) -> None:
        """Test the manual reset capability."""
        self.controller.velocity = np.array([5.0, 5.0, 5.0])
        self.controller.reset_state()
        np.testing.assert_array_equal(self.controller.velocity, np.zeros(3))


class TestSafetyLogic(unittest.TestCase):
    """Verifies ISO 15066 Speed and Separation Monitoring (6 Tests)."""

    def setUp(self) -> None:
        """Set up the monitor with known zones."""
        # Red: < 0.5m, Yellow: 0.5-2.0m, Green: > 2.0m
        self.cfg = SafetyConfig(min_dist=0.5, max_dist=2.0)
        self.monitor = SafetyMonitor(self.cfg)
        self.robot_pos = np.zeros(3)

    def test_invalid_config(self) -> None:
        """Ensure min_dist cannot be greater than max_dist."""
        bad_cfg = SafetyConfig(min_dist=3.0, max_dist=1.0)
        with self.assertRaises(ValueError):
            SafetyMonitor(bad_cfg)

    def test_red_zone_protective_stop(self) -> None:
        """Test strict cutoff inside minimum distance."""
        human_pos = np.array([0.49, 0.0, 0.0])
        scale = self.monitor.calculate_scaling_factor(self.robot_pos, human_pos)
        
        self.assertEqual(scale, 0.0)
        self.assertTrue(self.monitor.is_emergency_stop)

    def test_green_zone_free_run(self) -> None:
        """Test full speed outside maximum distance."""
        human_pos = np.array([2.1, 0.0, 0.0])
        scale = self.monitor.calculate_scaling_factor(self.robot_pos, human_pos)
        
        self.assertEqual(scale, 1.0)
        self.assertFalse(self.monitor.is_emergency_stop)

    def test_yellow_zone_scaling(self) -> None:
        """Test linear interpolation."""
        # Distance = 1.25m (Exactly middle of 0.5 and 2.0)
        # Scale should be 0.5
        human_pos = np.array([1.25, 0.0, 0.0])
        scale = self.monitor.calculate_scaling_factor(self.robot_pos, human_pos)
        
        self.assertAlmostEqual(scale, 0.5, places=5)

    def test_exact_boundary_min(self) -> None:
        """Test behavior exactly on the Red/Yellow border."""
        human_pos = np.array([0.5, 0.0, 0.0])
        scale = self.monitor.calculate_scaling_factor(self.robot_pos, human_pos)
        
        # Depending on implementation logic (< vs <=), this confirms behavior.
        # Our logic uses `distance < min_dist` for stop. So 0.5 is start of scaling (0.0).
        self.assertAlmostEqual(scale, 0.0, places=5)

    def test_invalid_inputs_fail_safe(self) -> None:
        """Ensure system stops if non-numpy arrays are passed."""
        # Suppress expected logging error for a clean test run
        logging.disable(logging.CRITICAL)
        
        try:
            # Passing lists instead of np.arrays triggers the fail-safe
            scale = self.monitor.calculate_scaling_factor([0, 0, 0], [1, 0, 0]) # type: ignore
            self.assertEqual(scale, 0.0, "System did not default to safe state on invalid input")
        finally:
            # Re-enable logging for subsequent tests
            logging.disable(logging.NOTSET)


if __name__ == "__main__":
    unittest.main()
    