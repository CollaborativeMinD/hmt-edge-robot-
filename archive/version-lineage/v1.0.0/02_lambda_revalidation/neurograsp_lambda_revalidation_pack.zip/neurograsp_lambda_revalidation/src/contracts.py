from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator


class MissionState(str, Enum):
    PRIMARY = 'PRIMARY'
    ALTERNATE = 'ALTERNATE'
    CONTINGENCY = 'CONTINGENCY'
    EMERGENCY = 'EMERGENCY'


class VisionConfigContract(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True, frozen=True)
    img_size: int = Field(default=600, ge=128, le=4096)
    min_area: float = Field(default=1000.0, gt=0.0)
    binary_threshold: int = Field(default=50, ge=0, le=255)
    scale_factor: int = Field(default=150, ge=1, le=1000)


class RobotConfigContract(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True, frozen=True)
    pixel_to_mm: float = Field(default=0.1, gt=0.0, le=100.0)
    angle_offset_deg: float = Field(default=90.0, ge=-360.0, le=360.0)


class FrameRequest(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True)
    cycle_id: int = Field(ge=0)
    chaos_mode: bool = False
    seed: int = Field(ge=0)


class FrameTelemetry(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True)
    schema_id: Literal['ng.frame.telemetry'] = 'ng.frame.telemetry'
    schema_version: Literal['1.0.0'] = '1.0.0'
    monotonic_seq: int = Field(ge=0)
    timestamp_utc: str
    state: MissionState
    frame_generated: bool
    recovery_attempted: bool
    determinism_hash: str = Field(min_length=8)

    @field_validator('timestamp_utc')
    @classmethod
    def validate_timestamp(cls, value: str) -> str:
        datetime.fromisoformat(value.replace('Z', '+00:00'))
        return value


class GraspObservation(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True)
    center_px_x: int
    center_px_y: int
    angle_deg: float
    center_mm_x: float
    center_mm_y: float
    robot_angle_deg: float
    primary_eigenvalue: float = Field(gt=0.0)
    secondary_eigenvalue: float = Field(gt=0.0)

    @model_validator(mode='after')
    def validate_eigen_order(self) -> 'GraspObservation':
        if self.primary_eigenvalue < self.secondary_eigenvalue:
            raise ValueError('primary eigenvalue must be >= secondary eigenvalue')
        return self


class GateResult(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True)
    gate_id: str
    status: Literal['PASS', 'FAIL', 'HOLD', 'ESCALATE', 'REJECT']
    criteria: list[str]
    fail_reasons: list[str]
    repair_required: bool
    escalation_required: bool


class ArtifactManifestEntry(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True)
    path: str
    sha256: str
    artifact_type: str
    purpose: str
    iteration_id: str
    timestamp_utc: str


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace('+00:00', 'Z')
