from __future__ import annotations

import hashlib
import math
from dataclasses import dataclass
from enum import Enum
from typing import Optional

import cv2
import numpy as np

from contracts import FrameRequest, FrameTelemetry, GraspObservation, MissionState, RobotConfigContract, VisionConfigContract, utc_now


@dataclass(frozen=True)
class VisionConfig:
    img_size: int = 600
    min_area: float = 1000.0
    binary_threshold: int = 50
    scale_factor: int = 150

    def validate(self) -> VisionConfigContract:
        return VisionConfigContract.model_validate(self.__dict__)


@dataclass(frozen=True)
class RobotConfig:
    pixel_to_mm: float = 0.1
    angle_offset_deg: float = 90.0

    def validate(self) -> RobotConfigContract:
        return RobotConfigContract.model_validate(self.__dict__)


class CameraState(str, Enum):
    PRIMARY = 'PRIMARY'
    ALTERNATE = 'ALTERNATE'
    CONTINGENCY = 'CONTINGENCY'
    EMERGENCY = 'EMERGENCY'


class DeterministicSyntheticCamera:
    def __init__(self, size: int = 600) -> None:
        self.size = size
        self.frame_count = 0
        self.state = CameraState.PRIMARY

    def reset(self) -> None:
        self.frame_count = 0
        self.state = CameraState.PRIMARY

    def _generate_frame(self, seed: int, simulate_failure: bool) -> np.ndarray:
        if simulate_failure:
            raise ConnectionError('synthetic signal interruption')
        rng = np.random.default_rng(seed)
        img = np.zeros((self.size, self.size, 3), dtype=np.uint8)
        width = int(rng.integers(100, 300))
        height = int(rng.integers(50, 100))
        angle = float(rng.integers(0, 360))
        center = (int(rng.integers(150, 450)), int(rng.integers(150, 450)))
        rect = ((center[0], center[1]), (width, height), angle)
        box = cv2.boxPoints(rect)
        box = np.intp(box)
        cv2.drawContours(img, [box], 0, (255, 255, 255), -1)
        return img

    def get_frame(self, request: FrameRequest) -> tuple[Optional[np.ndarray], FrameTelemetry]:
        FrameRequest.model_validate(request.model_dump())
        recovery_attempted = False
        try:
            frame = self._generate_frame(seed=request.seed, simulate_failure=request.chaos_mode)
            self.frame_count += 1
            self.state = CameraState.PRIMARY
        except ConnectionError:
            recovery_attempted = True
            self.state = CameraState.ALTERNATE
            try:
                frame = self._generate_frame(seed=request.seed + 1, simulate_failure=False)
                self.frame_count += 1
                self.state = CameraState.ALTERNATE
            except ConnectionError:
                frame = None
                self.state = CameraState.EMERGENCY
        digest = hashlib.sha256(f'{request.cycle_id}|{request.seed}|{self.state}|{self.frame_count}'.encode()).hexdigest()
        telemetry = FrameTelemetry(
            monotonic_seq=self.frame_count,
            timestamp_utc=utc_now(),
            state=MissionState(self.state.value),
            frame_generated=frame is not None,
            recovery_attempted=recovery_attempted,
            determinism_hash=digest,
        )
        return frame, telemetry


class VisionProcessor:
    def __init__(self, v_cfg: VisionConfig, r_cfg: RobotConfig) -> None:
        self.v_cfg = v_cfg
        self.r_cfg = r_cfg
        self.v_cfg.validate()
        self.r_cfg.validate()

    def threshold_and_find_contours(self, frame: np.ndarray) -> list[np.ndarray]:
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        _, thr = cv2.threshold(gray, self.v_cfg.binary_threshold, 255, cv2.THRESH_BINARY)
        contours, _ = cv2.findContours(thr, cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)
        return [c for c in contours if cv2.contourArea(c) >= self.v_cfg.min_area]

    def calculate_grasp_pose(self, contour: np.ndarray) -> GraspObservation:
        if contour.size == 0:
            raise ValueError('contour must not be empty')
        data_pts = contour.reshape(-1, 2).astype(np.float64)
        mean, eigenvectors, eigenvalues = cv2.PCACompute2(data_pts, np.array([]))
        center_px_x = int(mean[0, 0])
        center_px_y = int(mean[0, 1])
        angle_rad = math.atan2(float(eigenvectors[0, 1]), float(eigenvectors[0, 0]))
        angle_deg = math.degrees(angle_rad)
        center_mm_x = center_px_x * self.r_cfg.pixel_to_mm
        center_mm_y = center_px_y * self.r_cfg.pixel_to_mm
        robot_angle_deg = angle_deg + self.r_cfg.angle_offset_deg
        return GraspObservation(
            center_px_x=center_px_x,
            center_px_y=center_px_y,
            angle_deg=angle_deg,
            center_mm_x=center_mm_x,
            center_mm_y=center_mm_y,
            robot_angle_deg=robot_angle_deg,
            primary_eigenvalue=float(eigenvalues[0, 0]),
            secondary_eigenvalue=float(eigenvalues[1, 0]),
        )


class NeuroGraspSubsystem:
    def __init__(self, v_cfg: VisionConfig | None = None, r_cfg: RobotConfig | None = None) -> None:
        self.v_cfg = v_cfg or VisionConfig()
        self.r_cfg = r_cfg or RobotConfig()
        self.camera = DeterministicSyntheticCamera(size=self.v_cfg.img_size)
        self.processor = VisionProcessor(self.v_cfg, self.r_cfg)

    def run_cycle(self, cycle_id: int, seed: int, chaos_mode: bool = False) -> dict:
        request = FrameRequest(cycle_id=cycle_id, chaos_mode=chaos_mode, seed=seed)
        frame, telemetry = self.camera.get_frame(request)
        result: dict = {'telemetry': telemetry.model_dump(mode='json'), 'observation': None}
        if frame is None:
            return result
        contours = self.processor.threshold_and_find_contours(frame)
        if not contours:
            return result
        contour = max(contours, key=cv2.contourArea)
        observation = self.processor.calculate_grasp_pose(contour)
        result['observation'] = observation.model_dump(mode='json')
        return result
