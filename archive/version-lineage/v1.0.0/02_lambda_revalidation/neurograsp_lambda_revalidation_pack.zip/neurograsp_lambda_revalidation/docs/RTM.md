# Requirement Traceability Matrix

| Requirement ID | Requirement | Subsystem Element | Verification Method | Artifact Path | Status |
|---|---|---|---|---|---|
| NG-R1 | The subsystem shall compute a deterministic PCA-based grasp orientation from valid contour input. | VisionProcessor.calculate_grasp_pose | pytest + SIL campaign | tests/test_neuro_grasp_lambda.py | READY |
| NG-R2 | The subsystem shall transform pixel center to robot millimeter coordinates using declared scaling constants. | RobotConfig + VisionProcessor | pytest | tests/test_neuro_grasp_lambda.py | READY |
| NG-R3 | The subsystem shall use explicit PACE-like driver recovery semantics for transient camera failure. | DeterministicSyntheticCamera.get_frame | pytest + SIL campaign | tests/test_neuro_grasp_lambda.py | READY |
| NG-R4 | The subsystem shall emit validated telemetry contracts for each frame acquisition cycle. | FrameTelemetry contract | pytest + notebook validation | src/contracts.py | READY |
| NG-R5 | The subsystem shall support reproducible SIL execution using seeded synthetic generation. | DeterministicSyntheticCamera._generate_frame | pytest + notebook replay | tests/test_neuro_grasp_lambda.py | READY |
| NG-R6 | The subsystem shall maintain reviewable evidence artifacts for Lambda-model revalidation. | iteration_001.ipynb + evidence pack | executed notebook | runs/NG-001 | READY |
