# ICD_NeuroGrasp.VisionProcessor.GraspObservation.md

## ICD-1 Interface Record Header

| Field | Value |
|---|---|
| ICD_ID | ICD-NeuroGrasp.VisionProcessor.GraspObservation |
| ICD_NAME | Neuro-Grasp Validated Grasp Observation |
| ICD_STATUS | READY |
| PRODUCER | VisionProcessor |
| CONSUMER | Grasp planner / robot supervisor |
| INTERFACE_TYPE | DATA |
| DIRECTION | PRODUCER→CONSUMER |
| TRANSPORT | in-process |
| ENCODING | JSON |
| SCHEMA_ID | ng.grasp.observation |
| SCHEMA_VERSION | 1.0.0 |
| SECURITY_CLASS | INTERNAL |
| OWNERSHIP | PRODUCER |
| CHANGE_CONTROL | Git review by subsystem owner |

## ICD-2 Data Dictionary

| FieldName | Direction | Type | Units | Required | Constraints | Default | Example | Notes |
|---|---|---|---|---|---|---|---|---|
| center_px_x | OUT | int | px | Y | >=0 | n/a | 301 | centroid x |
| center_px_y | OUT | int | px | Y | >=0 | n/a | 244 | centroid y |
| angle_deg | OUT | float | deg | Y | finite | n/a | -18.6 | PCA major-axis angle |
| center_mm_x | OUT | float | mm | Y | >=0 | n/a | 30.1 | scaled x |
| center_mm_y | OUT | float | mm | Y | >=0 | n/a | 24.4 | scaled y |
| robot_angle_deg | OUT | float | deg | Y | finite | n/a | 71.4 | offset angle |
| primary_eigenvalue | OUT | float | none | Y | >0 | n/a | 12034.2 | PCA major variance |
| secondary_eigenvalue | OUT | float | none | Y | >0 | n/a | 2445.3 | PCA minor variance |

## ICD-3 Timing & Ordering Contract

| Parameter | Value | Notes |
|---|---|---|
| DELIVERY_MODE | EXACTLY_ONCE | per run_cycle return |
| ORDERING | SEQ_ENFORCED | cycle_id and monotonic_seq |
| MAX_LATENCY_MS | 100 | SIL workstation target |
| MAX_JITTER_MS | 20 | synthetic environment |
| UPDATE_RATE_HZ | 10 | nominal SIL replay rate |
| BURST_MAX | 1 | one observation per cycle |
| TIMEOUT_MS | 250 | camera acquisition timeout surrogate |
| CLOCK_SOURCE | PRODUCER | utc_now() |
| STALENESS_MS | 500 | stale in SIL context |
| RETRY_POLICY | fixed | one recovery attempt |

### Late / missing / out-of-order handling

| Condition | Detect | Classify | Consumer Action | Evidence |
|---|---|---|---|---|
| LATE | acquisition exceeds MAX_LATENCY_MS | DEGRADED | shift to Alternate and log event | notebook evidence |
| MISSING | frame_generated = false | FAIL | reject cycle and escalate | notebook evidence |
| OUT_OF_ORDER | monotonic_seq decreases | FAIL | reject payload | contract tests |
| STALE | timestamp older than STALENESS_MS | DEGRADED | ignore payload | notebook evidence |

## ICD-4 Failure Semantics

| Failure | Trigger | Detection Method | Producer Action | Consumer Action | Safe State | Recovery | Evidence |
|---|---|---|---|---|---|---|---|
| E_SCHEMA_INVALID | payload validation fails | Pydantic contract | reject + log | reject + log | CONTINGENCY | rerun cycle | contract tests |
| E_TIMEOUT | timeout budget exceeded | stopwatch in SIL notebook | set degraded state | ignore payload | ALTERNATE | rerun cycle | notebook evidence |
| E_TRANSPORT_DOWN | in-process call failure | exception | emit no payload | hold cycle | EMERGENCY | manual restart | notebook evidence |

## ICD-5 PACE Behavior

| Lane | Mechanism | Trigger | Detection | Expected Degradation | Recovery Procedure | Verification Evidence |
|---|---|---|---|---|---|---|
| Primary | seeded frame generation | no fault | no exception | none | continue | pytest + FAST |
| Alternate | one deterministic retry | transient camera interruption | ConnectionError | one-cycle recovery delay | retry with seed+1 | pytest + CERT |
| Contingency | reject frame, continue session | invalid payload or no contour | Pydantic failure / empty contour | no observation for cycle | log and continue | HOLDOUT |
| Emergency | terminate acquisition path | repeated failure | frame is None | mission degradation | manual reset | REGRESSION |

## ICD-6 Evidence Pack Requirements

| Artifact | Required | Location | Pass/Fail rule |
|---|---|---|---|
| JSON Schema | Y | notebook export | schema validates sample payloads |
| Contract tests | Y | tests/ | all tests pass |
| Golden payloads | Y | runs/NG-001/evidence | hashes reproducible |
| Logs | Y | runs/NG-001/logs | contain state transitions |
| RTM links | Y | docs/RTM.md | every interface maps to requirement |
