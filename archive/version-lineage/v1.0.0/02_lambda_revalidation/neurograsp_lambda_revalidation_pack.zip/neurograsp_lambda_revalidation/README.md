# Neuro-Grasp Lambda Revalidation Pack

This package is the Lambda-aligned SIL revalidation uplift for Neuro-Grasp.

It preserves the original deterministic PCA grasp concept and adds only the governance and evidence surfaces needed for real review:
- strict contracts at subsystem boundaries
- deterministic synthetic SIL source with seeded execution
- explicit supervisory state model
- ICD Normal Form document
- requirement traceability matrix
- SysML v2 textual architecture stub
- executable notebook producing evidence artifacts

## Execution

```bash
python -m pytest -q
jupyter nbconvert --to notebook --execute runs/NG-001/notebooks/iteration_001.ipynb --output iteration_001.executed.ipynb
```
