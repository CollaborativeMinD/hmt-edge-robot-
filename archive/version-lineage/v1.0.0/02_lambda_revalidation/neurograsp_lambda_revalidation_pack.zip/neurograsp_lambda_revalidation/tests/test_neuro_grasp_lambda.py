from __future__ import annotations

import math

import numpy as np

from contracts import FrameRequest, GraspObservation, VisionConfigContract, RobotConfigContract
from neuro_grasp_lambda import DeterministicSyntheticCamera, NeuroGraspSubsystem, RobotConfig, VisionConfig, VisionProcessor


def test_config_contracts_validate() -> None:
    assert VisionConfigContract.model_validate(VisionConfig().__dict__).img_size == 600
    assert RobotConfigContract.model_validate(RobotConfig().__dict__).pixel_to_mm == 0.1


def test_camera_is_deterministic_for_same_seed() -> None:
    cam = DeterministicSyntheticCamera(size=600)
    req = FrameRequest(cycle_id=1, chaos_mode=False, seed=123)
    frame1, telem1 = cam.get_frame(req)
    cam.reset()
    frame2, telem2 = cam.get_frame(req)
    assert frame1 is not None and frame2 is not None
    assert np.array_equal(frame1, frame2)
    assert telem1.determinism_hash == telem2.determinism_hash


def test_recovery_path_promotes_alternate_not_emergency() -> None:
    cam = DeterministicSyntheticCamera(size=600)
    frame, telemetry = cam.get_frame(FrameRequest(cycle_id=2, chaos_mode=True, seed=50))
    assert frame is not None
    assert telemetry.recovery_attempted is True
    assert telemetry.state.value == 'ALTERNATE'


def test_processor_returns_valid_grasp_observation() -> None:
    proc = VisionProcessor(VisionConfig(), RobotConfig(pixel_to_mm=1.0, angle_offset_deg=0.0))
    contour = np.array([[[100, 200]], [[500, 200]], [[500, 210]], [[100, 210]]])
    pose = proc.calculate_grasp_pose(contour)
    assert isinstance(pose, GraspObservation)
    assert math.isclose(abs(math.cos(math.radians(pose.angle_deg))), 1.0, rel_tol=1e-2)


def test_subsystem_run_cycle_returns_observation() -> None:
    system = NeuroGraspSubsystem()
    result = system.run_cycle(cycle_id=1, seed=99, chaos_mode=False)
    assert result['observation'] is not None


def test_empty_contour_rejected() -> None:
    proc = VisionProcessor(VisionConfig(), RobotConfig())
    try:
        proc.calculate_grasp_pose(np.array([]))
    except ValueError:
        assert True
    else:
        assert False
