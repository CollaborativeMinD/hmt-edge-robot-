# ICD_WaialuaEdgeNode.SensorBus.TelemetryAssessment

## 1) Interface Record Header (ICD-1)

| Field | Value |
|---|---|
| ICD_ID | ICD-WaialuaEdgeNode.SensorBus.TelemetryAssessment |
| ICD_NAME | Waialua Edge Node Telemetry Assessment |
| ICD_STATUS | CERTIFIED |
| PRODUCER | SensorBus |
| CONSUMER | WaialuaEdgeNodeLambda |
| INTERFACE_TYPE | DATA |
| DIRECTION | PRODUCER→CONSUMER |
| TRANSPORT | InProcess / Deterministic SIL Packet |
| ENCODING | Pydantic JSON |
| SCHEMA_ID | wen.telemetry |
| SCHEMA_VERSION | 1.0.0 |
| SECURITY_CLASS | INTERNAL |
| OWNERSHIP | JOINT |
| CHANGE_CONTROL | Principal Architect review |

## 2) Data Dictionary (ICD-2)

| FieldName | Direction | Type | Units | Required | Constraints | Default | Example | Notes |
|---|---|---|---|---|---|---|---|---|
| tick | IN | int | none | Y | >=0 | n/a | 3 | deterministic step id |
| time_sec | IN | decimal | s | Y | equals tick in SIL harness | n/a | 3.000 | deterministic replay clock |
| voltage_v | IN | decimal | V | Y | 0.000..5.000 | n/a | 3.680 | battery state |
| temp_c | IN | decimal | C | Y | -55.000..150.000 | n/a | 49.000 | raw thermal value |
| signal_dbm | IN | decimal | dBm | Y | -150.000..50.000 | n/a | -49.500 | raw signal value |

### 2.1 Determinism fields

| FieldName | Direction | Type | Units | Required | Constraints | Default | Example | Notes |
|---|---|---|---|---|---|---|---|---|
| schema_id | OUT | string | none | Y | non-empty | n/a | wen.telemetry | canonical registry id |
| schema_version | OUT | string | none | Y | semver | n/a | 1.0.0 | versioned contract |
| determinism_hash | OUT | string | none | Y | sha256 hex | n/a | 8c... | canonical content hash |
| monotonic_seq | OUT | int64 | none | Y | >=0 | 0 | 4 | monotonic sequence |
| tie_break_rule | OUT | string | none | Y | monotonic_seq | monotonic_seq | monotonic_seq | ordering rule |
| timestamp_utc | OUT | string | ISO-8601 | Y | valid datetime | n/a | 2026-03-27T20:00:00Z | production time |

## 3) Timing & Ordering Contract (ICD-3)

| Parameter | Value | Notes |
|---|---|---|
| DELIVERY_MODE | EXACTLY_ONCE | SIL packet consumed once |
| ORDERING | SEQ_ENFORCED | monotonic sequence enforced |
| MAX_LATENCY_MS | 50 | process budget |
| MAX_JITTER_MS | 0 | deterministic SIL |
| UPDATE_RATE_HZ | 1.0 / 0.2 | Primary / Alternate |
| BURST_MAX | 1 | one sample per tick |
| TIMEOUT_MS | 1000 | one primary-cycle budget |
| CLOCK_SOURCE | PRODUCER | deterministic SIL generator |
| STALENESS_MS | 1000 | >1 primary cycle is stale |
| RETRY_POLICY | none | deterministic replay only |

### 3.1 Late / missing / out-of-order handling

| Condition | Detect | Classify | Consumer Action | Evidence |
|---|---|---|---|---|
| LATE | process time > 50 ms | FAIL | reject sample, enter Emergency | notebook gate |
| MISSING | no message for timeout budget | FAIL | enter Emergency | HIL deferred |
| OUT_OF_ORDER | monotonic_seq decreases | FAIL | reject packet | contract test |
| STALE | timestamp older than staleness budget | FAIL | enter Emergency | HIL deferred |

## 4) Failure Semantics (ICD-4)

| Failure | Trigger | Detection Method | Producer Action | Consumer Action | Safe State | Recovery | Evidence |
|---|---|---|---|---|---|---|---|
| E_CONSTRAINT_VIOLATION | invalid field range | Pydantic validation | drop sample | reject packet | EMERGENCY | operator reseed | tests |
| E_STALE_DATA | stale sample age | timing gate | emit fault | halt telemetry | EMERGENCY | restart source | notebook |
| E_TIMEOUT | no sample within budget | timing gate | n/a | flush and halt | EMERGENCY | restart source | notebook |
| E_UNKNOWN | unclassified runtime error | exception path | log | halt | EMERGENCY | operator review | tests |

## 5) PACE Behavior (ICD-5)

| Lane | Mechanism | Trigger | Detection | Expected Degradation | Recovery Procedure | Verification Evidence |
|---|---|---|---|---|---|---|
| Primary | 1 Hz full telemetry | voltage > 3.700 V and temp <= 85 C | threshold compare | none | continue nominal loop | pytest + FAST |
| Alternate | 0.2 Hz power save | 3.400 V < voltage <= 3.700 V | threshold compare | slower polling only | continue low-rate loop | pytest + CERT |
| Contingency | ghost record | temp > 85 C | threshold compare | null payload fields for chain of custody | continue nominal poll with rejected data | pytest + HOLDOUT |
| Emergency | flush and halt | voltage <= 3.400 V or timing failure | threshold or timing gate | telemetry stops | restart subsystem | pytest + REGRESSION |

## 6) Evidence Pack Requirements (ICD-6)

| Artifact | Required | Location | Pass/Fail rule |
|---|---|---|---|
| JSON Schema | Y | `src/contracts.py` | schema validates packets |
| Contract tests | Y | `tests/test_waialua_edge_node_lambda.py` | all tests pass |
| Golden payloads | Y | notebook outputs | hashes stable |
| Logs | Y | notebook outputs | transitions visible |
| RTM links | Y | `docs/RTM.md` | every requirement mapped |
