# Requirement Traceability Matrix | Waialua Edge Node Lambda

| Requirement ID | Requirement | Artifact | Verification Method | Status |
|---|---|---|---|---|
| WEN-R1 | The subsystem shall enter Alternate power-save mode when battery voltage is `<= 3.700 V` and `> 3.400 V`. | `src/waialua_edge_node_lambda.py` | `test_nominal_to_degraded_transition` | PASS |
| WEN-R2 | The subsystem shall enter Emergency mode and require flush/halt when battery voltage is `<= 3.400 V`. | `src/waialua_edge_node_lambda.py` | `test_emergency_flush_and_halt` | PASS |
| WEN-R3 | The subsystem shall reject thermal inputs above `85.000 C` and emit a ghost record preserving deterministic chain of custody. | `src/waialua_edge_node_lambda.py` | `test_thermal_guardrail_creates_ghost_record` | PASS |
| WEN-R4 | The subsystem shall emit evidence-grade telemetry with canonical determinism fields and stable hash generation. | `src/contracts.py`, `src/waialua_edge_node_lambda.py` | `test_hash_is_deterministic` | PASS |
| WEN-R5 | The subsystem shall support deterministic SIL replay that traverses Primary, Alternate, Contingency, and Emergency lanes. | `src/sil_campaign.py` | `test_harness_reaches_all_required_lanes` | PASS |
| WEN-R6 | The subsystem shall provide executable Lambda notebook evidence with FAST, CERT, HOLDOUT, and REGRESSION results. | `runs/WEN-001/notebooks/iteration_001.executed.ipynb` | executed notebook | PASS |
