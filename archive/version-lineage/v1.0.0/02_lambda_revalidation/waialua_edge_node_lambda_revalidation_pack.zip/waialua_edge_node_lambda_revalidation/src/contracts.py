
from __future__ import annotations

from datetime import datetime, timezone
from decimal import Decimal, ROUND_HALF_UP
from enum import Enum
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator


Q3 = Decimal('0.001')
Q4 = Decimal('0.0001')


def q3(value: Decimal | float | str) -> Decimal:
    return Decimal(str(value)).quantize(Q3, rounding=ROUND_HALF_UP)


def q4(value: Decimal | float | str) -> Decimal:
    return Decimal(str(value)).quantize(Q4, rounding=ROUND_HALF_UP)


class RuntimeState(str, Enum):
    NOMINAL = 'NOMINAL'
    DEGRADED = 'DEGRADED'
    EMERGENCY = 'EMERGENCY'


class PaceLane(str, Enum):
    PRIMARY = 'PRIMARY'
    ALTERNATE = 'ALTERNATE'
    CONTINGENCY = 'CONTINGENCY'
    EMERGENCY = 'EMERGENCY'


class SensorSample(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True, frozen=True)
    tick: int = Field(ge=0)
    time_sec: Decimal = Field(ge=Decimal('0.000'))
    voltage_v: Decimal = Field(ge=Decimal('0.000'), le=Decimal('5.000'))
    temp_c: Decimal = Field(ge=Decimal('-55.000'), le=Decimal('150.000'))
    signal_dbm: Decimal = Field(ge=Decimal('-150.000'), le=Decimal('50.000'))

    @field_validator('time_sec', 'voltage_v', 'temp_c', 'signal_dbm', mode='before')
    @classmethod
    def coerce_decimal(cls, value):
        return q3(value)

    @model_validator(mode='after')
    def validate_tick_time(self):
        expected = q3(Decimal(self.tick))
        if self.time_sec != expected:
            raise ValueError('time_sec must equal tick value in deterministic SIL harness')
        return self


class SystemConfigContract(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True, frozen=True)
    max_temp_c: Decimal = Field(gt=Decimal('0.000'), le=Decimal('150.000'))
    nominal_voltage_v: Decimal = Field(gt=Decimal('0.000'), le=Decimal('5.000'))
    safe_voltage_v: Decimal = Field(gt=Decimal('0.000'), le=Decimal('5.000'))
    primary_poll_sec: Decimal = Field(gt=Decimal('0.000'), le=Decimal('60.000'))
    alternate_poll_sec: Decimal = Field(gt=Decimal('0.000'), le=Decimal('60.000'))
    emergency_flush_sec: Decimal = Field(gt=Decimal('0.000'), le=Decimal('60.000'))
    process_budget_sec: Decimal = Field(gt=Decimal('0.000'), le=Decimal('60.000'))
    ghost_fill_temp: str = Field(min_length=1, default='NULL')
    ghost_fill_signal: str = Field(min_length=1, default='NULL')

    @field_validator('*', mode='before')
    @classmethod
    def coerce_decimal_fields(cls, value, info):
        if info.field_name in {'ghost_fill_temp', 'ghost_fill_signal'}:
            return value
        return q3(value)

    @model_validator(mode='after')
    def validate_thresholds(self):
        if self.safe_voltage_v >= self.nominal_voltage_v:
            raise ValueError('safe_voltage_v must be < nominal_voltage_v')
        if self.alternate_poll_sec <= self.primary_poll_sec:
            raise ValueError('alternate_poll_sec must be > primary_poll_sec')
        if self.process_budget_sec >= self.primary_poll_sec:
            raise ValueError('process_budget_sec must be < primary_poll_sec')
        return self


class TelemetryPacket(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True)
    schema_id: Literal['wen.telemetry'] = 'wen.telemetry'
    schema_version: Literal['1.0.0'] = '1.0.0'
    determinism_hash: str = Field(min_length=8)
    monotonic_seq: int = Field(ge=0)
    tie_break_rule: Literal['monotonic_seq'] = 'monotonic_seq'
    timestamp_utc: str
    tick: int = Field(ge=0)
    input_voltage_v: Decimal
    runtime_state: RuntimeState
    pace_lane: PaceLane
    poll_interval_sec: Decimal
    accepted_temp_c: Decimal | None = None
    accepted_signal_dbm: Decimal | None = None
    thermal_excursion: bool
    battery_margin: Decimal
    temp_margin: Decimal
    data_valid: bool
    flush_required: bool
    message: str

    @field_validator('input_voltage_v', 'poll_interval_sec', 'battery_margin', 'temp_margin', mode='before')
    @classmethod
    def val_q3(cls, value):
        return q3(value)

    @field_validator('accepted_temp_c', 'accepted_signal_dbm', mode='before')
    @classmethod
    def optional_q3(cls, value):
        if value is None:
            return None
        return q3(value)

    @field_validator('timestamp_utc')
    @classmethod
    def validate_timestamp(cls, value: str) -> str:
        datetime.fromisoformat(value.replace('Z', '+00:00'))
        return value


class GateResult(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True)
    gate_id: str
    status: Literal['PASS', 'FAIL', 'HOLD', 'ESCALATE', 'REJECT']
    criteria: list[str]
    fail_reasons: list[str]
    repair_required: bool
    escalation_required: bool


class ArtifactManifestEntry(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True)
    path: str
    sha256: str
    artifact_type: str
    purpose: str
    iteration_id: str
    timestamp_utc: str


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace('+00:00', 'Z')
