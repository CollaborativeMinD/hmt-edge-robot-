
from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Iterable

try:
    import polars as pl
except Exception:  # pragma: no cover
    pl = None

try:
    import pandas as pd
except Exception:  # pragma: no cover
    pd = None

from src.contracts import (
    PaceLane,
    RuntimeState,
    SensorSample,
    SystemConfigContract,
    TelemetryPacket,
    q3,
    utc_now,
)


@dataclass(frozen=True)
class SystemConfig:
    max_temp_c: Decimal = Decimal('85.000')
    nominal_voltage_v: Decimal = Decimal('3.700')
    safe_voltage_v: Decimal = Decimal('3.400')
    primary_poll_sec: Decimal = Decimal('1.000')
    alternate_poll_sec: Decimal = Decimal('5.000')
    emergency_flush_sec: Decimal = Decimal('0.250')
    process_budget_sec: Decimal = Decimal('0.050')
    ghost_fill_temp: str = 'NULL'
    ghost_fill_signal: str = 'NULL'

    def validate(self) -> SystemConfigContract:
        return SystemConfigContract.model_validate(self.__dict__)


@dataclass
class EngineState:
    seq: int = 0
    runtime_state: RuntimeState = RuntimeState.NOMINAL
    pace_lane: PaceLane = PaceLane.PRIMARY
    halted: bool = False
    history: list[dict] = field(default_factory=list)


class WaialuaEdgeNodeLambda:
    def __init__(self, config: SystemConfig = SystemConfig()) -> None:
        self.config = config
        self.contract = config.validate()
        self.state = EngineState()

    def battery_margin(self, voltage_v: Decimal) -> Decimal:
        span = self.config.nominal_voltage_v - self.config.safe_voltage_v
        if voltage_v <= self.config.safe_voltage_v:
            return Decimal('0.000')
        if voltage_v >= self.config.nominal_voltage_v:
            return Decimal('1.000')
        return q3((voltage_v - self.config.safe_voltage_v) / span)

    def temp_margin(self, temp_c: Decimal) -> Decimal:
        if temp_c >= self.config.max_temp_c:
            return Decimal('0.000')
        return q3(Decimal('1.000') - (temp_c / self.config.max_temp_c))

    def classify(self, sample: SensorSample) -> tuple[RuntimeState, PaceLane, Decimal]:
        if sample.voltage_v <= self.config.safe_voltage_v:
            return RuntimeState.EMERGENCY, PaceLane.EMERGENCY, self.config.emergency_flush_sec
        if sample.temp_c > self.config.max_temp_c:
            return RuntimeState.NOMINAL, PaceLane.CONTINGENCY, self.config.primary_poll_sec
        if sample.voltage_v <= self.config.nominal_voltage_v:
            return RuntimeState.DEGRADED, PaceLane.ALTERNATE, self.config.alternate_poll_sec
        return RuntimeState.NOMINAL, PaceLane.PRIMARY, self.config.primary_poll_sec

    def process(self, sample: SensorSample) -> dict:
        if self.state.halted:
            raise RuntimeError('node halted after emergency transition')
        runtime_state, pace_lane, poll_sec = self.classify(sample)
        thermal_excursion = sample.temp_c > self.config.max_temp_c
        accepted_temp = None if thermal_excursion or runtime_state == RuntimeState.EMERGENCY else sample.temp_c
        accepted_signal = None if thermal_excursion or runtime_state == RuntimeState.EMERGENCY else sample.signal_dbm
        flush_required = runtime_state == RuntimeState.EMERGENCY
        message = 'nominal'
        if runtime_state == RuntimeState.DEGRADED:
            message = 'power-save'
        elif pace_lane == PaceLane.CONTINGENCY:
            message = 'thermal-ghost-record'
        elif runtime_state == RuntimeState.EMERGENCY:
            message = 'flush-and-halt'
        self.state.runtime_state = runtime_state
        self.state.pace_lane = pace_lane
        payload = {
            'schema_id': 'wen.telemetry',
            'schema_version': '1.0.0',
            'monotonic_seq': self.state.seq,
            'timestamp_utc': utc_now(),
            'tick': sample.tick,
            'input_voltage_v': sample.voltage_v,
            'runtime_state': runtime_state,
            'pace_lane': pace_lane,
            'poll_interval_sec': poll_sec,
            'accepted_temp_c': accepted_temp,
            'accepted_signal_dbm': accepted_signal,
            'thermal_excursion': thermal_excursion,
            'battery_margin': self.battery_margin(sample.voltage_v),
            'temp_margin': self.temp_margin(sample.temp_c),
            'data_valid': not thermal_excursion and runtime_state != RuntimeState.EMERGENCY,
            'flush_required': flush_required,
            'message': message,
        }
        core = '|'.join([
            payload['schema_id'],
            payload['schema_version'],
            str(payload['monotonic_seq']),
            payload['runtime_state'].value,
            payload['pace_lane'].value,
            str(payload['tick']),
            str(payload['input_voltage_v']),
            str(payload['poll_interval_sec']),
            str(payload['thermal_excursion']),
            str(payload['flush_required']),
        ])
        payload['determinism_hash'] = hashlib.sha256(core.encode()).hexdigest()
        model = TelemetryPacket.model_validate(payload)
        result = model.model_dump(mode='json')
        self.state.history.append(result)
        self.state.seq += 1
        if runtime_state == RuntimeState.EMERGENCY:
            self.state.halted = True
        return result

    def as_frame(self):
        if pl is not None:
            if not self.state.history:
                return pl.DataFrame()
            return pl.DataFrame(self.state.history)
        if pd is not None:
            return pd.DataFrame(self.state.history)
        return self.state.history


def deterministic_harness() -> list[SensorSample]:
    values = [
        (0, '4.200', '45.000', '-48.000'),
        (1, '4.050', '46.000', '-47.500'),
        (2, '3.900', '47.000', '-49.000'),
        (3, '3.760', '48.000', '-50.000'),
        (4, '3.680', '49.000', '-49.500'),
        (5, '3.620', '86.000', '-52.000'),
        (6, '3.550', '50.000', '-51.000'),
        (7, '3.430', '51.000', '-50.500'),
        (8, '3.390', '52.000', '-50.000'),
    ]
    return [
        SensorSample.model_validate({
            'tick': tick,
            'time_sec': f'{tick:.3f}',
            'voltage_v': voltage,
            'temp_c': temp,
            'signal_dbm': signal,
        })
        for tick, voltage, temp, signal in values
    ]


def run_harness(samples: Iterable[SensorSample] | None = None) -> list[dict]:
    node = WaialuaEdgeNodeLambda()
    outputs = []
    for sample in samples or deterministic_harness():
        outputs.append(node.process(sample))
        if outputs[-1]['runtime_state'] == RuntimeState.EMERGENCY:
            break
    return outputs
