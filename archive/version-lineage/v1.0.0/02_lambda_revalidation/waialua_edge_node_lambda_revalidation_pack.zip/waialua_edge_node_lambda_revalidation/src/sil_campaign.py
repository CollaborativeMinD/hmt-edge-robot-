
from __future__ import annotations

from collections import Counter

from src.contracts import PaceLane, RuntimeState, SensorSample
from src.waialua_edge_node_lambda import WaialuaEdgeNodeLambda, deterministic_harness


def make_holdout_samples() -> list[SensorSample]:
    values = [
        (0, '4.100', '44.000', '-47.000'),
        (1, '3.850', '45.000', '-48.000'),
        (2, '3.690', '46.000', '-49.000'),
        (3, '3.610', '87.000', '-50.000'),
        (4, '3.500', '49.000', '-51.000'),
        (5, '3.401', '50.000', '-51.500'),
        (6, '3.399', '51.000', '-52.000'),
    ]
    return [
        SensorSample.model_validate({
            'tick': tick,
            'time_sec': f'{tick:.3f}',
            'voltage_v': voltage,
            'temp_c': temp,
            'signal_dbm': signal,
        })
        for tick, voltage, temp, signal in values
    ]


def run_campaign(samples: list[SensorSample]) -> dict:
    node = WaialuaEdgeNodeLambda()
    results = []
    for sample in samples:
        results.append(node.process(sample))
        if results[-1]['runtime_state'] == RuntimeState.EMERGENCY:
            break
    counts = Counter([r['pace_lane'] for r in results])
    return {
        'steps': len(results),
        'primary_steps': counts.get(PaceLane.PRIMARY.value, 0),
        'alternate_steps': counts.get(PaceLane.ALTERNATE.value, 0),
        'contingency_steps': counts.get(PaceLane.CONTINGENCY.value, 0),
        'emergency_steps': counts.get(PaceLane.EMERGENCY.value, 0),
        'final_state': results[-1]['runtime_state'],
        'all_hashes_unique': len({r['determinism_hash'] for r in results}) == len(results),
        'emergency_reached': results[-1]['runtime_state'] == RuntimeState.EMERGENCY.value,
        'success': (
            len(results) >= 5
            and counts.get(PaceLane.CONTINGENCY.value, 0) >= 1
            and counts.get(PaceLane.ALTERNATE.value, 0) >= 1
            and results[-1]['runtime_state'] == RuntimeState.EMERGENCY.value
        ),
    }


def run_all() -> dict[str, dict]:
    fast = run_campaign(deterministic_harness())
    cert = run_campaign(deterministic_harness())
    holdout = run_campaign(make_holdout_samples())
    regression = run_campaign(deterministic_harness())
    return {'FAST': fast, 'CERT': cert, 'HOLDOUT': holdout, 'REGRESSION': regression}
