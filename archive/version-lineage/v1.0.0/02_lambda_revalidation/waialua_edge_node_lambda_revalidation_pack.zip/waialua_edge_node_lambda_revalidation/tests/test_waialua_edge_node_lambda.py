
from __future__ import annotations

from decimal import Decimal
import hashlib

from src.contracts import PaceLane, RuntimeState, SensorSample, SystemConfigContract
from src.sil_campaign import run_all
from src.waialua_edge_node_lambda import WaialuaEdgeNodeLambda, deterministic_harness


def sample(tick: int, voltage: str, temp: str, signal: str = '-50.000') -> SensorSample:
    return SensorSample.model_validate({
        'tick': tick,
        'time_sec': f'{tick:.3f}',
        'voltage_v': voltage,
        'temp_c': temp,
        'signal_dbm': signal,
    })


def test_config_contract_validates():
    cfg = SystemConfigContract.model_validate({
        'max_temp_c': '85.000',
        'nominal_voltage_v': '3.700',
        'safe_voltage_v': '3.400',
        'primary_poll_sec': '1.000',
        'alternate_poll_sec': '5.000',
        'emergency_flush_sec': '0.250',
        'process_budget_sec': '0.050',
        'ghost_fill_temp': 'NULL',
        'ghost_fill_signal': 'NULL',
    })
    assert cfg.safe_voltage_v < cfg.nominal_voltage_v


def test_nominal_to_degraded_transition():
    node = WaialuaEdgeNodeLambda()
    pkt1 = node.process(sample(0, '4.100', '45.000'))
    pkt2 = node.process(sample(1, '3.650', '46.000'))
    assert pkt1['runtime_state'] == RuntimeState.NOMINAL.value
    assert pkt1['pace_lane'] == PaceLane.PRIMARY.value
    assert pkt2['runtime_state'] == RuntimeState.DEGRADED.value
    assert pkt2['pace_lane'] == PaceLane.ALTERNATE.value
    assert pkt2['poll_interval_sec'] in (Decimal('5.000'), '5.000')


def test_thermal_guardrail_creates_ghost_record():
    node = WaialuaEdgeNodeLambda()
    pkt = node.process(sample(0, '3.800', '98.500'))
    assert pkt['pace_lane'] == PaceLane.CONTINGENCY.value
    assert pkt['accepted_temp_c'] is None
    assert pkt['accepted_signal_dbm'] is None
    assert pkt['data_valid'] is False
    assert pkt['message'] == 'thermal-ghost-record'


def test_emergency_flush_and_halt():
    node = WaialuaEdgeNodeLambda()
    pkt = node.process(sample(0, '3.390', '50.000'))
    assert pkt['runtime_state'] == RuntimeState.EMERGENCY.value
    assert pkt['flush_required'] is True
    assert pkt['pace_lane'] == PaceLane.EMERGENCY.value


def test_hash_is_deterministic():
    node = WaialuaEdgeNodeLambda()
    pkt = node.process(sample(0, '4.000', '45.000'))
    core = '|'.join([
        'wen.telemetry', '1.0.0', '0', 'NOMINAL', 'PRIMARY', '0', '4.000', '1.000', 'False', 'False'
    ])
    assert pkt['determinism_hash'] == hashlib.sha256(core.encode()).hexdigest()


def test_harness_reaches_all_required_lanes():
    outputs = deterministic_harness()
    node = WaialuaEdgeNodeLambda()
    seen = set()
    for s in outputs:
        pkt = node.process(s)
        seen.add(pkt['pace_lane'])
        if pkt['runtime_state'] == RuntimeState.EMERGENCY.value:
            break
    assert PaceLane.PRIMARY.value in seen
    assert PaceLane.ALTERNATE.value in seen
    assert PaceLane.CONTINGENCY.value in seen
    assert PaceLane.EMERGENCY.value in seen


def test_campaigns_all_pass():
    results = run_all()
    assert all(v['success'] for v in results.values())
    assert all(v['all_hashes_unique'] for v in results.values())


def test_polars_frame_materializes():
    node = WaialuaEdgeNodeLambda()
    for s in deterministic_harness():
        pkt = node.process(s)
        if pkt['runtime_state'] == RuntimeState.EMERGENCY.value:
            break
    df = node.as_frame()
    if hasattr(df, 'height'):
        assert df.height >= 1
        assert 'runtime_state' in df.columns
    elif hasattr(df, '__len__') and hasattr(df, 'columns'):
        assert len(df) >= 1
        assert 'runtime_state' in list(df.columns)
    else:
        assert len(df) >= 1
        assert 'runtime_state' in df[0]
