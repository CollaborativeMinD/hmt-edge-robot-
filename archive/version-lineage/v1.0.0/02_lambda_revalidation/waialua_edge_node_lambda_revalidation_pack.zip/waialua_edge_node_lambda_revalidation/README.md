# Waialua Edge Node Lambda Revalidation Pack

This package is the Lambda-aligned SIL uplift for Waialua Edge Node.

It preserves the original power-adaptive telemetry mission, while adding the mathematical, programmatic, and deterministic surfaces needed for subsystem review:
- Decimal-safe voltage and thermal threshold handling
- strict Pydantic v2 contracts at subsystem boundaries
- deterministic PACE supervisory semantics
- ghost-record contingency behavior with evidence-grade telemetry
- ICD Normal Form document
- requirement traceability matrix
- SysML v2 textual architecture slice
- executable notebook producing evidence artifacts
- reproducible FAST, CERT, HOLDOUT, and REGRESSION SIL campaigns

## Execution

```bash
python -m pytest -q
jupyter nbconvert --to notebook --execute runs/WEN-001/notebooks/iteration_001.ipynb --output iteration_001.executed.ipynb
```
