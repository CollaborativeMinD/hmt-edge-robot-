
import unittest
import numpy as np
from halosafe_lambda import (
    AdmittanceController, SafetyMonitor, PhysicsConfig, SafetyConfig,
    PositionPacket, HaloState, run_sil_campaign, summarize_campaign
)

class TestHaloSafeLambda(unittest.TestCase):
    def setUp(self):
        self.controller = AdmittanceController(PhysicsConfig(mass=10.0, damping=5.0, stiffness=0.0, dt=0.1))
        self.monitor = SafetyMonitor(SafetyConfig(min_dist=0.5, max_dist=2.0))
        self.robot_pos = np.zeros(3)

    def test_invalid_mass_raises(self):
        with self.assertRaises(ValueError):
            AdmittanceController(PhysicsConfig(mass=0.0))

    def test_invalid_distances_raise(self):
        with self.assertRaises(ValueError):
            SafetyConfig(min_dist=2.0, max_dist=1.0)

    def test_physics_step(self):
        pos, vel, acc = self.controller.step(np.array([10.0, 0.0, 0.0]))
        self.assertAlmostEqual(acc[0], 1.0, places=5)
        self.assertAlmostEqual(vel[0], 0.1, places=5)
        self.assertAlmostEqual(pos[0], 0.01, places=5)

    def test_damping(self):
        self.controller.velocity = np.array([1.0, 0.0, 0.0])
        _, vel, _ = self.controller.step(np.zeros(3))
        self.assertAlmostEqual(vel[0], 0.95, places=5)

    def test_red_zone_stop(self):
        scale = self.monitor.calculate_scaling_factor(self.robot_pos, np.array([0.4, 0, 0]))
        self.assertEqual(scale, 0.0)
        self.assertTrue(self.monitor.is_emergency_stop)

    def test_green_zone_full(self):
        scale = self.monitor.calculate_scaling_factor(self.robot_pos, np.array([2.5, 0, 0]))
        self.assertEqual(scale, 1.0)

    def test_yellow_zone_scale(self):
        scale = self.monitor.calculate_scaling_factor(self.robot_pos, np.array([1.25, 0, 0]))
        self.assertAlmostEqual(scale, 0.5, places=5)

    def test_packet_hash_present(self):
        pkt = PositionPacket(monotonic_seq=1, timestamp_utc="2026-03-27T12:00:00Z", x_m=1.0, y_m=0.0, z_m=0.0)
        self.assertTrue(bool(pkt.determinism_hash))

    def test_assessment_state(self):
        robot = PositionPacket(monotonic_seq=1, timestamp_utc="2026-03-27T12:00:00Z", x_m=0.0, y_m=0.0, z_m=0.0)
        human = PositionPacket(monotonic_seq=1, timestamp_utc="2026-03-27T12:00:00Z", x_m=0.4, y_m=0.0, z_m=0.0)
        a = self.monitor.assess(robot, human)
        self.assertEqual(a.state, HaloState.EMERGENCY_STOP)
        self.assertEqual(a.gate_id, "HS-G3")

    def test_sil_campaign_summary(self):
        res = run_sil_campaign(steps=40, seed=11)
        summary = summarize_campaign(res)
        self.assertEqual(summary["total_steps"], 40)
        self.assertGreater(summary["safe_rate"], 0.0)
        self.assertGreater(summary["warn_rate"], 0.0)

if __name__ == "__main__":
    unittest.main()
