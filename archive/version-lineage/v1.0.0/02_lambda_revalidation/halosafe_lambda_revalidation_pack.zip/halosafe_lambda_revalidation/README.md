# HaloSafe Lambda Revalidation Pack

## Purpose
This package contains the Lambda Model uplift and SIL revalidation baseline for the HaloSafe subsystem.

HaloSafe is treated here as a completed early prototype that required deterministic governance uplift, documentation normalization, and executable evidence artifacts before downstream HIL or field-facing integration.

## What this pack includes
- `src/halosafe_lambda.py`  
  Lambda-aligned subsystem logic for proximity assessment, warning-band scaling, and protective stop behavior.
- `src/contracts.py`  
  Pydantic v2 contracts for evidence-grade packets, gate results, and manifest entries.
- `tests/test_halosafe_lambda.py`  
  Deterministic unit and SIL-aligned regression tests.
- `docs/RTM.md`  
  Requirement Traceability Matrix.
- `docs/ICD_HaloSafe.HRI.ProximityAssessment.md`  
  ICD written in ICD Normal Form.
- `models/halosafe_lambda.sysml`  
  SysML v2 textual architecture slice.
- `runs/HS-001/notebooks/iteration_001.executed.ipynb`  
  Executed notebook evidence artifact.
- `runs/HS-001/evidence/`  
  FAST, CERT, HOLDOUT, and REGRESSION outputs.
- `runs/HS-001/manifests/artifact_manifest.json`  
  Artifact manifest with evidence tracking.

## Mission role
HaloSafe enforces separation-aware motion governance for human-robot interaction.

It evaluates operator-to-robot distance, determines the current safety lane, computes permitted motion scaling, and forces protective stop behavior when minimum separation is violated or when packet validity cannot be trusted.

## Lambda uplift applied
The following uplift actions were applied without adding non-essential operator burden:
- Added strict contract validation at subsystem boundaries.
- Added deterministic packet hashing and canonical evidence serialization.
- Added explicit PACE supervisory semantics.
- Added RTM coverage for subsystem requirements.
- Added ICD Normal Form documentation for the primary evidence seam.
- Added SysML v2 textual model coverage.
- Added executed notebook evidence aligned to the neuro-symbolic notebook doctrine.
- Added repeatable SIL campaign outputs for FAST, CERT, HOLDOUT, and REGRESSION.

## Validation status
- Pytest: PASS
- FAST: PASS
- CERT: PASS
- HOLDOUT: PASS
- REGRESSION: PASS
- Final notebook decision: PASS

## Operator notes
This package is the SIL revalidation baseline.

It is not the final HIL or deployment certification pack.

For next-step uplift, preserve the contracts, RTM IDs, ICD structure, and notebook rhythm. Swap only the external acquisition or runtime seam required for hardware integration.
