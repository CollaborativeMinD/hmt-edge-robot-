
# ICD-HaloSafe.HRI.ProximityAssessment

## ICD-1 Header

| Field | Value |
|---|---|
| ICD_ID | ICD-HaloSafe.HRI.ProximityAssessment |
| ICD_NAME | Human Robot Proximity Assessment Interface |
| ICD_STATUS | READY |
| PRODUCER | HaloSafe/HRI Sensor Path |
| CONSUMER | HaloSafe Safety Monitor |
| INTERFACE_TYPE | DATA |
| DIRECTION | PRODUCER→CONSUMER |
| TRANSPORT | InProcess |
| ENCODING | JSON |
| SCHEMA_ID | halosafe.position |
| SCHEMA_VERSION | 1.0.0 |
| SECURITY_CLASS | INTERNAL |
| OWNERSHIP | JOINT |
| CHANGE_CONTROL | Repo PR + notebook evidence gate |

## ICD-2 Data Dictionary

| FieldName | Direction | Type | Units | Required | Constraints | Default | Example | Notes |
|---|---|---|---|---|---|---|---|---|
| schema_id | OUT | string | none | Y | non-empty | halosafe.position | halosafe.position | Canonical schema id |
| schema_version | OUT | string | none | Y | semver | 1.0.0 | 1.0.0 | Versioned contract |
| determinism_hash | OUT | string | none | Y | sha256 hex | n/a | abc123 | Canonical payload hash |
| monotonic_seq | OUT | int64 | none | Y | >=0 | 0 | 42 | Ordering key |
| tie_break_rule | OUT | string | none | Y | non-empty | monotonic_seq | monotonic_seq | Ordering rule |
| timestamp_utc | OUT | string | ISO-8601 | Y | valid UTC | n/a | 2026-03-27T12:00:00Z | Production time |
| x_m | OUT | float | m | Y | finite | n/a | 1.25 | x position |
| y_m | OUT | float | m | Y | finite | 0.0 | 0.0 | y position |
| z_m | OUT | float | m | Y | finite | 0.0 | 0.0 | z position |

## ICD-3 Timing & Ordering

| Parameter | Value | Notes |
|---|---|---|
| DELIVERY_MODE | EXACTLY_ONCE | In-process synthetic SIL |
| ORDERING | SEQ_ENFORCED | monotonic_seq |
| MAX_LATENCY_MS | 50 | One dt cycle |
| MAX_JITTER_MS | 5 | SIL budget |
| UPDATE_RATE_HZ | 20 | dt=0.05 |
| BURST_MAX | 1 | single packet |
| TIMEOUT_MS | 100 | two dt cycles |
| CLOCK_SOURCE | PRODUCER | generated packet time |
| STALENESS_MS | 100 | stale after two cycles |
| RETRY_POLICY | none | deterministic path |

### 3.1 Late / missing / out-of-order handling

| Condition | Detect | Classify | Consumer Action | Evidence |
|---|---|---|---|---|
| LATE | now - timestamp_utc > 50 ms | DEGRADED | enter Alternate/Warn | notebook + tests |
| MISSING | no message for 100 ms | FAIL | Emergency stop | notebook + tests |
| OUT_OF_ORDER | monotonic_seq decreases | FAIL | reject packet, stop | notebook + tests |
| STALE | age > 100 ms | FAIL | reject packet, stop | notebook + tests |

## ICD-4 Failure Semantics

| Failure | Trigger | Detection Method | Producer Action | Consumer Action | Safe State | Recovery | Evidence |
|---|---|---|---|---|---|---|---|
| E_SCHEMA_INVALID | parse/validate fails | Pydantic | drop + log | reject + stop | EMERGENCY_STOP | resend valid packet | tests + notebook |
| E_TIMEOUT | TIMEOUT_MS exceeded | timer | n/a | switch lane | EMERGENCY_STOP | restore source | tests + notebook |
| E_OUT_OF_ORDER | seq rollback | sequence check | drop + log | reject + stop | EMERGENCY_STOP | reset stream | tests + notebook |

## ICD-5 PACE Behavior

| Lane | Mechanism | Trigger | Detection | Expected Degradation | Recovery Procedure | Verification Evidence |
|---|---|---|---|---|---|---|
| Primary | full-speed supervisory passage | distance > max_dist | distance check | none | maintain route | FAST/CERT |
| Alternate | linear velocity scaling | min_dist <= distance <= max_dist | distance check | reduced speed | return to Primary when clear | FAST/CERT/HOLDOUT |
| Contingency | packet rejection and hold | malformed packet or transient seam issue | schema/shape validation | commanded motion suppressed | resend valid packet | unit tests |
| Emergency | protective stop | distance < min_dist or stale/missing packet | threshold + timing | full stop | operator reset / valid data restoration | CERT/REGRESSION |
