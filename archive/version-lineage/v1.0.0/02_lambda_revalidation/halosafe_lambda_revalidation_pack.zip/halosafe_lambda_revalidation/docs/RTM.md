
# HaloSafe Lambda RTM

| Requirement ID | Derived Requirement | Subsystem | ICD Seam | Validation Method | Artifact Path | Status | Owner |
|---|---|---|---|---|---|---|---|
| HS-R1 | Enforce protective stop below minimum separation | HaloSafe Safety Monitor | ICD-HaloSafe.HRI.ProximityAssessment | Unit tests + SIL | tests/test_halosafe_lambda.py | PASS | SafetyMonitor |
| HS-R2 | Scale velocity linearly in warn band | HaloSafe Safety Monitor | ICD-HaloSafe.HRI.ProximityAssessment | Unit tests + CERT | tests/test_halosafe_lambda.py | PASS | SafetyMonitor |
| HS-R3 | Maintain deterministic physics update law | Admittance Controller | ICD-HaloSafe.Controller.MotionState | Unit tests | tests/test_halosafe_lambda.py | PASS | AdmittanceController |
| HS-R4 | Validate evidence-grade packets with determinism fields | Contract Layer | ICD-HaloSafe.HRI.ProximityAssessment | Pydantic schema validation | src/halosafe_lambda.py | PASS | Pydantic |
| HS-R5 | Provide reproducible SIL campaign replay | SIL Harness | ICD-HaloSafe.HRI.ProximityAssessment | FAST/CERT/HOLDOUT/REGRESSION | runs/HS-001/evidence | PASS | SIL Harness |
| HS-R6 | Preserve notebook-executable evidence chain | Notebook Governance | n/a | Executed notebook gate | runs/HS-001/notebooks/iteration_001.executed.ipynb | PASS | Notebook |
