
from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
from typing import Literal, Optional
import hashlib
import json
import math
import numpy as np
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

class HaloState(str, Enum):
    PRIMARY_SAFE = "PRIMARY_SAFE"
    ALTERNATE_WARN = "ALTERNATE_WARN"
    CONTINGENCY_REJECT = "CONTINGENCY_REJECT"
    EMERGENCY_STOP = "EMERGENCY_STOP"

@dataclass(frozen=True)
class PhysicsConfig:
    mass: float = 5.0
    damping: float = 10.0
    stiffness: float = 0.0
    dt: float = 0.05

@dataclass(frozen=True)
class SafetyConfig:
    min_dist: float = 0.5
    max_dist: float = 2.0

    def __post_init__(self):
        if self.min_dist <= 0 or self.max_dist <= 0:
            raise ValueError("Safety distances must be positive")
        if self.min_dist >= self.max_dist:
            raise ValueError("min_dist must be < max_dist")

class PositionPacket(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)
    schema_id: str = "halosafe.position"
    schema_version: str = "1.0.0"
    monotonic_seq: int = Field(ge=0)
    timestamp_utc: str
    x_m: float
    y_m: float
    z_m: float
    tie_break_rule: str = "monotonic_seq"
    determinism_hash: Optional[str] = None

    @field_validator("timestamp_utc")
    @classmethod
    def valid_ts(cls, v: str):
        if "T" not in v or not v.endswith("Z"):
            raise ValueError("timestamp_utc must be ISO-8601 UTC")
        return v

    @model_validator(mode="after")
    def set_hash(self):
        if self.determinism_hash is None:
            payload = self.model_dump(mode="json", exclude={"determinism_hash"})
            canon = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
            object.__setattr__(self, "determinism_hash", hashlib.sha256(canon).hexdigest())
        return self

    def as_array(self) -> np.ndarray:
        return np.array([self.x_m, self.y_m, self.z_m], dtype=float)

class SafetyAssessment(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)
    state: HaloState
    scale_factor: float = Field(ge=0.0, le=1.0)
    human_distance_m: float = Field(ge=0.0)
    gate_id: str
    rationale: str

class AdmittanceController:
    def __init__(self, config: PhysicsConfig):
        if config.mass <= 0:
            raise ValueError("mass must be positive")
        if config.dt <= 0:
            raise ValueError("dt must be positive")
        self.cfg = config
        self.position = np.zeros(3, dtype=float)
        self.velocity = np.zeros(3, dtype=float)

    def reset_state(self):
        self.position[:] = 0.0
        self.velocity[:] = 0.0

    def step(self, external_force: np.ndarray, reference_position: Optional[np.ndarray] = None):
        external_force = np.asarray(external_force, dtype=float)
        if external_force.shape != (3,):
            raise ValueError("external_force must be shape (3,)")
        if reference_position is None:
            reference_position = self.position.copy()
        reference_position = np.asarray(reference_position, dtype=float)
        if reference_position.shape != (3,):
            raise ValueError("reference_position must be shape (3,)")
        damping_force = self.cfg.damping * self.velocity
        spring_force = self.cfg.stiffness * (self.position - reference_position)
        acceleration = (external_force - damping_force - spring_force) / self.cfg.mass
        self.velocity = self.velocity + acceleration * self.cfg.dt
        self.position = self.position + self.velocity * self.cfg.dt
        return self.position.copy(), self.velocity.copy(), acceleration.copy()

class SafetyMonitor:
    def __init__(self, config: SafetyConfig):
        self.cfg = config
        self._last_scale_factor = 1.0

    @property
    def is_emergency_stop(self) -> bool:
        return self._last_scale_factor == 0.0

    def calculate_scaling_factor(self, robot_pos: np.ndarray, human_pos: np.ndarray) -> float:
        robot_pos = np.asarray(robot_pos, dtype=float)
        human_pos = np.asarray(human_pos, dtype=float)
        if robot_pos.shape != (3,) or human_pos.shape != (3,):
            self._last_scale_factor = 0.0
            return 0.0
        distance = float(np.linalg.norm(robot_pos - human_pos))
        if not math.isfinite(distance):
            self._last_scale_factor = 0.0
            return 0.0
        if distance < self.cfg.min_dist:
            scale = 0.0
        elif distance > self.cfg.max_dist:
            scale = 1.0
        else:
            denom = self.cfg.max_dist - self.cfg.min_dist
            scale = float(np.clip((distance - self.cfg.min_dist) / denom, 0.0, 1.0))
        self._last_scale_factor = scale
        return scale

    def assess(self, robot_packet: PositionPacket, human_packet: PositionPacket) -> SafetyAssessment:
        distance = float(np.linalg.norm(robot_packet.as_array() - human_packet.as_array()))
        scale = self.calculate_scaling_factor(robot_packet.as_array(), human_packet.as_array())
        if scale == 1.0:
            state = HaloState.PRIMARY_SAFE
            gate = "HS-G1"
            rationale = "Human outside max_dist; full-speed permissible."
        elif scale == 0.0:
            state = HaloState.EMERGENCY_STOP
            gate = "HS-G3"
            rationale = "Human inside min_dist; protective stop required."
        else:
            state = HaloState.ALTERNATE_WARN
            gate = "HS-G2"
            rationale = "Human in warn band; velocity scaling required."
        return SafetyAssessment(
            state=state, scale_factor=scale, human_distance_m=distance, gate_id=gate, rationale=rationale
        )

def simulate_human_distance(t: float, avg_dist: float = 1.7, amp: float = 1.3, freq: float = 0.4) -> float:
    return avg_dist + amp * math.sin(t * freq)

def run_sil_campaign(steps: int = 120, seed: int = 7):
    rng = np.random.default_rng(seed)
    controller = AdmittanceController(PhysicsConfig())
    monitor = SafetyMonitor(SafetyConfig())
    robot_pos = np.zeros(3, dtype=float)
    results = []
    for i in range(steps):
        t = i * controller.cfg.dt
        human_dist = simulate_human_distance(t) + float(rng.normal(0.0, 0.03))
        human_dist = max(0.0, human_dist)
        human_packet = PositionPacket(monotonic_seq=i, timestamp_utc="2026-03-27T12:00:00Z", x_m=float(human_dist), y_m=0.0, z_m=0.0)
        robot_packet = PositionPacket(monotonic_seq=i, timestamp_utc="2026-03-27T12:00:00Z", x_m=float(robot_pos[0]), y_m=0.0, z_m=0.0)
        assessment = monitor.assess(robot_packet, human_packet)
        _, velocity, _ = controller.step(np.array([15.0, 0.0, 0.0], dtype=float))
        safe_velocity = float(velocity[0] * assessment.scale_factor)
        results.append({
            "step": i,
            "t_s": t,
            "human_distance_m": human_dist,
            "state": assessment.state.value,
            "scale_factor": assessment.scale_factor,
            "safe_velocity_x_mps": safe_velocity,
            "gate_id": assessment.gate_id
        })
    return results

def summarize_campaign(results):
    total = len(results)
    emergency = sum(r["state"] == HaloState.EMERGENCY_STOP.value for r in results)
    warn = sum(r["state"] == HaloState.ALTERNATE_WARN.value for r in results)
    safe = sum(r["state"] == HaloState.PRIMARY_SAFE.value for r in results)
    return {
        "total_steps": total,
        "emergency_steps": emergency,
        "warn_steps": warn,
        "safe_steps": safe,
        "emergency_rate": emergency/total if total else 0.0,
        "warn_rate": warn/total if total else 0.0,
        "safe_rate": safe/total if total else 0.0,
    }
