
from __future__ import annotations
from typing import Literal, List
from pydantic import BaseModel, ConfigDict, Field

class RTMRow(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)
    requirement_id: str
    derived_requirement: str
    subsystem: str
    icd_seam: str
    validation_method: str
    artifact_path: str
    status: Literal["PASS", "FAIL", "HOLD"]
    owner: str

class GateResult(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)
    gate_id: str
    status: Literal["PASS", "FAIL", "HOLD", "ESCALATE", "REJECT"]
    criteria: List[str]
    fail_reasons: List[str]
    repair_required: bool
    escalation_required: bool

class ArtifactManifestEntry(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)
    path: str
    sha256: str
    artifact_type: str
    purpose: str
    iteration_id: str
    timestamp_utc: str

class DigitalTwinPacket(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)
    mission_id: str
    iteration_id: str
    subsystem_states: dict
    validated_bounds: dict
    gate_states: dict
    degradation_mode: str
    artifact_refs: list[str]
    overall_disposition: str
