# ICD_AccessManager.Operator.OverrideAssessment

## ICD-1 Header

| Field | Value |
|---|---|
| ICD_ID | ICD-AccessManager.Operator.OverrideAssessment |
| ICD_NAME | Operator Override Assessment Interface |
| ICD_STATUS | READY |
| PRODUCER | Operator Console |
| CONSUMER | AccessManager |
| INTERFACE_TYPE | CONTROL |
| DIRECTION | PRODUCER→CONSUMER |
| TRANSPORT | In-process call |
| ENCODING | Python dict / validated model |
| SCHEMA_ID | am.override.request |
| SCHEMA_VERSION | 1.0.0 |
| SECURITY_CLASS | INTERNAL |
| OWNERSHIP | JOINT |
| CHANGE_CONTROL | Lambda uplift baseline |

## ICD-2 Data Dictionary

| FieldName | Direction | Type | Units | Required | Constraints | Default | Example | Notes |
|---|---|---|---|---|---|---|---|---|
| badge_id | IN | string | none | Y | non-empty, exact cache key | n/a | ARCH-001 | badge identity |
| voice_intent | IN | string | none | Y | non-empty, recognized command | n/a | admin override | normalized lower-case at validation |
| schema_id | OUT | string | none | Y | non-empty | am.access.telemetry | am.access.telemetry | evidence-grade telemetry |
| schema_version | OUT | string | none | Y | semver | 1.0.0 | 1.0.0 | contract version |
| determinism_hash | OUT | string | none | Y | non-empty hex | n/a | abc123... | canonical digest |
| monotonic_seq | OUT | int64 | none | Y | >=0 | 0 | 4 | evidence ordering |
| timestamp_utc | OUT | ISO-8601 string | UTC | Y | valid datetime | n/a | 2026-03-28T00:00:00Z | production time |

## ICD-3 Timing & Ordering Contract

| Parameter | Value | Notes |
|---|---|---|
| DELIVERY_MODE | EXACTLY_ONCE | local validated call |
| ORDERING | SEQ_ENFORCED | monotonic sequence enforced in telemetry |
| MAX_LATENCY_MS | 50 | in-process decision target |
| MAX_JITTER_MS | 10 | negligible local variance |
| UPDATE_RATE_HZ | 1 | watchdog pulse nominal |
| BURST_MAX | 1 | single override command |
| TIMEOUT_MS | 300000 | 300 second watchdog |
| CLOCK_SOURCE | PRODUCER | monotonic call-time input |
| STALENESS_MS | 1000 | stale pulse beyond 1 second is advisory degradation |
| RETRY_POLICY | none | caller retries explicitly |

### Late / missing / out-of-order handling

| Condition | Detect | Classify | Consumer Action | Evidence |
|---|---|---|---|---|
| LATE | pulse arrives after expected window | DEGRADED | retain current state, assess timeout on next pulse | notebook logs |
| MISSING | no heartbeat for TIMEOUT_MS | FAIL | secure logout and enter Emergency | pytest + SIL |
| OUT_OF_ORDER | monotonic sequence decreases | FAIL | reject telemetry packet | contract layer |
| STALE | pulse older than STALENESS_MS | DEGRADED | suppress trust and await next pulse | notebook logs |

## ICD-4 Failure Semantics

| Failure | Trigger | Detection Method | Producer Action | Consumer Action | Safe State | Recovery | Evidence |
|---|---|---|---|---|---|---|---|
| E_SCHEMA_INVALID | blank or malformed request | Pydantic validation | reject input | reject + log | PRIMARY | resubmit valid packet | tests |
| E_TIMEOUT | elapsed > 300s | watchdog check | n/a | secure logout | EMERGENCY | new authenticated override | tests + SIL |
| E_STALE_DATA | pulse not refreshed | monotonic timing | resend heartbeat | degrade trust | ALTERNATE | fresh pulse | SIL |

## ICD-5 PACE Behavior

| Lane | Mechanism | Trigger | Detection | Expected Degradation | Recovery Procedure | Verification Evidence |
|---|---|---|---|---|---|---|
| Primary | No active override, safe guards active | no active session | internal state check | none | authenticated request | pytest + notebook |
| Alternate | Valid override session with watchdog | successful 2-FA | badge + intent validation | supervised override only | ongoing heartbeat | pytest + SIL |
| Contingency | Invalid badge or invalid intent | auth failure | contract + cache check | request rejected | retry with valid credentials | pytest |
| Emergency | Watchdog timeout or forced secure logout | elapsed > 300s | watchdog logic | override dropped, safe mode | new authenticated override | pytest + SIL |

## ICD-6 Evidence Pack Requirements

| Artifact | Required | Location | Pass/Fail rule |
|---|---|---|---|
| JSON Schema | Y | contract model export path by code | contract validates sample payloads |
| Contract tests | Y | `tests/test_accessmanager_lambda.py` | all tests pass |
| Golden payloads | Y | notebook outputs | hashes stable |
| Logs | Y | `runs/AM-001/evidence/` | contain suite results |
| RTM links | Y | `docs/RTM.md` | every interface maps to requirement |
