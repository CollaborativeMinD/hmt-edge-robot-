# AccessManager Requirement Traceability Matrix

| Requirement ID | Requirement | Artifact | Verification Method | Status |
|---|---|---|---|---|
| AM-R1 | The subsystem shall grant override only to authenticated badge IDs and valid intents. | `src/accessmanager_lambda.py` | pytest handshake tests | PASS |
| AM-R2 | The subsystem shall assign deterministic tiered clearance based on badge class. | `src/accessmanager_lambda.py` | pytest tier tests | PASS |
| AM-R3 | The subsystem shall revert to safe mode when watchdog timeout exceeds 300 seconds. | `src/accessmanager_lambda.py` | boundary and timeout tests | PASS |
| AM-R4 | The subsystem shall reject malformed boundary packets via strict contracts. | `src/contracts.py` | Pydantic validation tests | PASS |
| AM-R5 | The subsystem shall support reproducible SIL replays with deterministic scenario outcomes. | `src/accessmanager_lambda.py` | FAST/CERT/HOLDOUT/REGRESSION campaign | PASS |
| AM-R6 | The subsystem shall emit executable evidence in notebook form. | `runs/AM-001/notebooks/iteration_001.executed.ipynb` | notebook execution | PASS |
