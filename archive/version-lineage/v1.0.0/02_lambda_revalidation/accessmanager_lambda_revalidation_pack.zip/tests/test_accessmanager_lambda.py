from __future__ import annotations

import pytest

from src.accessmanager_lambda import AccessConfig, AccessManagerLambda, TIER_1, TIER_2, TIER_3, run_sil_campaign
from src.contracts import AccessConfigContract, OverrideRequest


def test_admin_handshake_success() -> None:
    mgr = AccessManagerLambda()
    granted = mgr.request_override('ARCH-001', 'admin override', now_monotonic=0.0)
    assert granted is True
    assert mgr.active_session == TIER_3


def test_maintenance_handshake_success() -> None:
    mgr = AccessManagerLambda()
    granted = mgr.request_override('MAINT-900', 'start maintenance', now_monotonic=0.0)
    assert granted is True
    assert mgr.active_session == TIER_2


def test_standard_handshake_success() -> None:
    mgr = AccessManagerLambda()
    granted = mgr.request_override('OP-7721', 'system check', now_monotonic=0.0)
    assert granted is True
    assert mgr.active_session == TIER_1


def test_invalid_badge_rejection() -> None:
    mgr = AccessManagerLambda()
    assert mgr.request_override('GHOST-007', 'admin override', now_monotonic=0.0) is False
    assert mgr.active_session is None


def test_invalid_intent_rejection() -> None:
    mgr = AccessManagerLambda()
    assert mgr.request_override('ARCH-001', 'open bay doors', now_monotonic=0.0) is False
    assert mgr.active_session is None


def test_watchdog_exact_boundary() -> None:
    mgr = AccessManagerLambda()
    mgr.request_override('MAINT-900', 'start maintenance', now_monotonic=0.0)
    active, _ = mgr.maintenance_pulse(False, now_monotonic=300.0)
    assert active is True


def test_watchdog_timeout_trigger() -> None:
    mgr = AccessManagerLambda()
    mgr.request_override('MAINT-900', 'start maintenance', now_monotonic=0.0)
    active, msg = mgr.maintenance_pulse(False, now_monotonic=301.0)
    assert active is False
    assert 'EMERGENCY' in msg
    assert mgr.is_override_active is False


def test_heartbeat_renewal() -> None:
    mgr = AccessManagerLambda()
    mgr.request_override('MAINT-900', 'start maintenance', now_monotonic=0.0)
    active, _ = mgr.maintenance_pulse(True, now_monotonic=50.0)
    assert active is True
    assert mgr.last_presence_time == 50.0


def test_contract_rejects_blank_override() -> None:
    with pytest.raises(Exception):
        OverrideRequest.model_validate({'badge_id': ' ', 'voice_intent': 'admin override'})


def test_config_contract_validates_cache() -> None:
    contract = AccessConfigContract.model_validate({'maintenance_timeout_sec': 10.0, 'heartbeat_threshold_sec': 1.0, 'auth_cache': {'A': 'B'}})
    assert contract.maintenance_timeout_sec == 10.0


def test_sil_campaign_passes_all() -> None:
    results = run_sil_campaign()
    assert all(row['pass'] for suite in results.values() for row in suite)
