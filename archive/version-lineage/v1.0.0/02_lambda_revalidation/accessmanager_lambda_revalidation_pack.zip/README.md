# AccessManager Lambda Revalidation Pack

This package is the Lambda-aligned SIL revalidation uplift for AccessManager.

It preserves the original deterministic administrative override and watchdog logic, while adding only the governance and evidence surfaces needed for real subsystem review:
- strict Pydantic v2 contracts at subsystem boundaries
- deterministic supervisory state semantics
- explicit PACE behavior and watchdog failure semantics
- ICD Normal Form document
- requirement traceability matrix
- SysML v2 textual architecture slice
- executable notebook producing evidence artifacts

## Execution

```bash
python -m pytest -q
jupyter nbconvert --to notebook --execute runs/AM-001/notebooks/iteration_001.ipynb --output iteration_001.executed.ipynb
```
