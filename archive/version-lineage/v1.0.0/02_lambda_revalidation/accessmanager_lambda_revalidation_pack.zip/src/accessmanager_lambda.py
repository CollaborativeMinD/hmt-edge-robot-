from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from typing import Final

from src.contracts import AccessConfigContract, AccessTelemetry, HeartbeatPacket, MissionState, OverrideRequest, utc_now


@dataclass(frozen=True)
class AccessConfig:
    maintenance_timeout_sec: Final[float] = 300.0
    heartbeat_threshold_sec: Final[float] = 1.0
    auth_cache: dict[str, str] = field(default_factory=lambda: {
        'OP-7721': 'Standard Operator',
        'MAINT-900': 'Maintenance Tech',
        'ARCH-001': 'Senior Architect',
    })

    def validate(self) -> AccessConfigContract:
        return AccessConfigContract.model_validate({
            'maintenance_timeout_sec': self.maintenance_timeout_sec,
            'heartbeat_threshold_sec': self.heartbeat_threshold_sec,
            'auth_cache': self.auth_cache,
        })


@dataclass(frozen=True)
class ClearanceLevel:
    name: str
    tier_id: int
    speed_limit_scale: float
    stiffness_boost: float


TIER_1: Final[ClearanceLevel] = ClearanceLevel('Standard', 1, 0.5, 1.0)
TIER_2: Final[ClearanceLevel] = ClearanceLevel('Maintenance', 2, 0.8, 1.5)
TIER_3: Final[ClearanceLevel] = ClearanceLevel('Admin', 3, 1.0, 2.0)
VALID_INTENTS = {'start maintenance', 'admin override', 'system check'}


class AccessManagerLambda:
    def __init__(self, config: AccessConfig = AccessConfig()) -> None:
        self.cfg = config
        self.cfg.validate()
        self._active_session: ClearanceLevel | None = None
        self._active_badge: str | None = None
        self._last_presence_time: float = 0.0
        self._seq: int = 0
        self._state: MissionState = MissionState.PRIMARY

    @property
    def active_session(self) -> ClearanceLevel | None:
        return self._active_session

    @property
    def active_badge(self) -> str | None:
        return self._active_badge

    @property
    def last_presence_time(self) -> float:
        return self._last_presence_time

    @last_presence_time.setter
    def last_presence_time(self, value: float) -> None:
        self._last_presence_time = value

    @property
    def is_override_active(self) -> bool:
        return self._active_session is not None

    def _clearance_from_badge(self, badge: str) -> ClearanceLevel:
        if badge.startswith('ARCH'):
            return TIER_3
        if badge.startswith('MAINT'):
            return TIER_2
        return TIER_1

    def request_override(self, badge_id: str, voice_intent: str, now_monotonic: float = 0.0) -> bool:
        req = OverrideRequest.model_validate({'badge_id': badge_id, 'voice_intent': voice_intent})
        clean_badge = req.badge_id.strip()
        clean_intent = req.voice_intent.strip().lower()
        if clean_badge not in self.cfg.auth_cache:
            self._state = MissionState.CONTINGENCY
            return False
        if clean_intent not in VALID_INTENTS:
            self._state = MissionState.CONTINGENCY
            return False
        self._active_session = self._clearance_from_badge(clean_badge)
        self._active_badge = clean_badge
        self._last_presence_time = now_monotonic
        self._state = MissionState.ALTERNATE
        self._seq += 1
        return True

    def maintenance_pulse(self, operator_present: bool, now_monotonic: float) -> tuple[bool, str]:
        HeartbeatPacket.model_validate({'operator_present': operator_present, 'now_monotonic': now_monotonic})
        if not self.is_override_active:
            self._state = MissionState.PRIMARY
            return True, 'STANDBY: No active override.'
        if operator_present:
            self._last_presence_time = now_monotonic
        elapsed = now_monotonic - self._last_presence_time
        if elapsed > self.cfg.maintenance_timeout_sec:
            self.secure_logout()
            self._state = MissionState.EMERGENCY
            self._seq += 1
            return False, 'EMERGENCY: Watchdog timeout. Reverting to Safe Mode.'
        self._state = MissionState.ALTERNATE
        self._seq += 1
        remaining = int(self.cfg.maintenance_timeout_sec - elapsed)
        return True, f'ACTIVE: Session confirmed. Timeout in {remaining}s'

    def secure_logout(self) -> None:
        self._active_session = None
        self._active_badge = None
        self._last_presence_time = 0.0

    def get_telemetry(self, now_monotonic: float) -> AccessTelemetry:
        if not self.is_override_active:
            digest = hashlib.sha256(f'{self._seq}|SAFE|{self._state}'.encode()).hexdigest()
            return AccessTelemetry(
                determinism_hash=digest,
                monotonic_seq=self._seq,
                timestamp_utc=utc_now(),
                state=self._state,
                active=False,
                time_left_sec=0.0,
                message='STANDBY',
            )
        elapsed = max(0.0, now_monotonic - self._last_presence_time)
        time_left = max(0.0, self.cfg.maintenance_timeout_sec - elapsed)
        digest = hashlib.sha256(f'{self._seq}|{self._active_badge}|{self._state}|{round(time_left,3)}'.encode()).hexdigest()
        return AccessTelemetry(
            determinism_hash=digest,
            monotonic_seq=self._seq,
            timestamp_utc=utc_now(),
            state=self._state,
            active=True,
            badge_id=self._active_badge,
            tier_name=self._active_session.name if self._active_session else None,
            time_left_sec=time_left,
            message='ACTIVE',
        )


def run_sil_campaign() -> dict[str, list[dict[str, object]]]:
    scenarios = {
        'FAST': [
            {'name': 'valid_maintenance', 'badge': 'MAINT-900', 'intent': 'start maintenance', 'pulse_time': 10.0, 'present': True, 'expect': True},
            {'name': 'invalid_badge', 'badge': 'GHOST-007', 'intent': 'admin override', 'pulse_time': 0.0, 'present': False, 'expect': False},
        ],
        'CERT': [
            {'name': 'admin_active_boundary', 'badge': 'ARCH-001', 'intent': 'admin override', 'pulse_time': 300.0, 'present': False, 'expect': True},
            {'name': 'timeout_301', 'badge': 'MAINT-900', 'intent': 'start maintenance', 'pulse_time': 301.0, 'present': False, 'expect': False},
        ],
        'HOLDOUT': [
            {'name': 'case_insensitive_intent', 'badge': 'MAINT-900', 'intent': 'START MAINTENANCE', 'pulse_time': 20.0, 'present': True, 'expect': True},
            {'name': 'blank_intent_rejected', 'badge': 'ARCH-001', 'intent': ' ', 'pulse_time': 0.0, 'present': False, 'expect': False},
        ],
        'REGRESSION': [
            {'name': 'standard_check', 'badge': 'OP-7721', 'intent': 'system check', 'pulse_time': 50.0, 'present': True, 'expect': True},
            {'name': 'lowercase_badge_rejected', 'badge': 'arch-001', 'intent': 'admin override', 'pulse_time': 0.0, 'present': False, 'expect': False},
        ],
    }
    results: dict[str, list[dict[str, object]]] = {}
    for suite, items in scenarios.items():
        suite_results: list[dict[str, object]] = []
        for item in items:
            mgr = AccessManagerLambda()
            passed_request = False
            try:
                passed_request = mgr.request_override(item['badge'], item['intent'], now_monotonic=0.0)
            except Exception:
                passed_request = False
            if passed_request:
                pulse_ok, msg = mgr.maintenance_pulse(bool(item['present']), float(item['pulse_time']))
            else:
                pulse_ok, msg = (False, 'REQUEST_REJECTED')
            telemetry = mgr.get_telemetry(now_monotonic=float(item['pulse_time']))
            actual = bool(passed_request and pulse_ok)
            suite_results.append({
                'scenario': item['name'],
                'expected': item['expect'],
                'actual': actual,
                'pass': actual == bool(item['expect']),
                'state': telemetry.state.value,
                'message': msg,
            })
        results[suite] = suite_results
    return results
