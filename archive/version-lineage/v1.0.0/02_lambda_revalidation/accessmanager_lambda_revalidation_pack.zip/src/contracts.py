from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator


class MissionState(str, Enum):
    PRIMARY = 'PRIMARY'
    ALTERNATE = 'ALTERNATE'
    CONTINGENCY = 'CONTINGENCY'
    EMERGENCY = 'EMERGENCY'


class AccessConfigContract(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True, frozen=True)
    maintenance_timeout_sec: float = Field(default=300.0, gt=0.0, le=3600.0)
    heartbeat_threshold_sec: float = Field(default=1.0, gt=0.0, le=60.0)
    auth_cache: dict[str, str] = Field(default_factory=dict)

    @field_validator('auth_cache')
    @classmethod
    def validate_cache(cls, value: dict[str, str]) -> dict[str, str]:
        if not value:
            raise ValueError('auth_cache must not be empty')
        return value


class OverrideRequest(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True)
    badge_id: str = Field(min_length=1)
    voice_intent: str = Field(min_length=1)

    @field_validator('badge_id', 'voice_intent')
    @classmethod
    def no_blank(cls, value: str) -> str:
        cleaned = value.strip()
        if not cleaned:
            raise ValueError('blank values are not allowed')
        return cleaned


class HeartbeatPacket(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True)
    operator_present: bool
    now_monotonic: float = Field(ge=0.0)


class AccessTelemetry(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True)
    schema_id: Literal['am.access.telemetry'] = 'am.access.telemetry'
    schema_version: Literal['1.0.0'] = '1.0.0'
    determinism_hash: str = Field(min_length=8)
    monotonic_seq: int = Field(ge=0)
    timestamp_utc: str
    state: MissionState
    active: bool
    badge_id: str | None = None
    tier_name: str | None = None
    time_left_sec: float = Field(ge=0.0)
    message: str

    @field_validator('timestamp_utc')
    @classmethod
    def validate_timestamp(cls, value: str) -> str:
        datetime.fromisoformat(value.replace('Z', '+00:00'))
        return value


class GateResult(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True)
    gate_id: str
    status: Literal['PASS', 'FAIL', 'HOLD', 'ESCALATE', 'REJECT']
    criteria: list[str]
    fail_reasons: list[str]
    repair_required: bool
    escalation_required: bool


class ArtifactManifestEntry(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True)
    path: str
    sha256: str
    artifact_type: str
    purpose: str
    iteration_id: str
    timestamp_utc: str


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace('+00:00', 'Z')
