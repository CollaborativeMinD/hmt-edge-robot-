# Factory Orchestrator Lambda Revalidation Pack

This package is the Lambda-aligned SIL uplift for Factory Orchestrator.

It preserves the original deterministic FSM and PACE fault handling, while adding only the governance and precision surfaces needed for real subsystem review:
- Decimal-based numerical handling for coordinates and safety thresholds
- strict Pydantic v2 contracts at subsystem boundaries
- deterministic supervisory state semantics and PACE behavior
- ICD Normal Form document
- requirement traceability matrix
- SysML v2 textual architecture slice
- executable notebook producing evidence artifacts
- reproducible FAST, CERT, HOLDOUT, and REGRESSION SIL campaigns

## Execution

```bash
python -m pytest -q
jupyter nbconvert --to notebook --execute runs/FO-001/notebooks/iteration_001.ipynb --output iteration_001.executed.ipynb
```
