from decimal import Decimal
from src.factory_orchestrator_lambda import FactoryOrchestratorLambda, MockHaloSafe, MockNeuroGrasp, MockRobotDriver, RobotState, SystemConfig


def test_boot_sequence_success():
    xo = FactoryOrchestratorLambda(MockHaloSafe(), MockNeuroGrasp(), MockRobotDriver(), SystemConfig(clock_cycle_sec=Decimal('0.001'), boot_delay_sec=Decimal('0.001'), scan_retry_delay_sec=Decimal('0.001'), task_wait_sec=Decimal('0.001')))
    xo.ctx.state = RobotState.BOOT
    xo.run_cycle()
    assert xo.ctx.state == RobotState.IDLE


def test_scanning_to_execution_nominal():
    driver = MockRobotDriver()
    xo = FactoryOrchestratorLambda(MockHaloSafe(), MockNeuroGrasp(), driver, SystemConfig(clock_cycle_sec=Decimal('0.001'), boot_delay_sec=Decimal('0.001'), scan_retry_delay_sec=Decimal('0.001'), task_wait_sec=Decimal('0.001')))
    xo.ctx.state = RobotState.SCANNING
    xo.run_cycle()
    assert xo.ctx.state == RobotState.PLANNING
    xo.run_cycle()
    assert xo.ctx.state == RobotState.EXECUTING
    xo.run_cycle()
    assert driver.moves[-1] == (Decimal('10.000'), Decimal('20.000'), Decimal('30.000'))
    assert driver.gripper_states[-1] == 'CLOSE'


def test_safety_rejection_returns_idle():
    xo = FactoryOrchestratorLambda(MockHaloSafe(safe_sum_limit_mm=Decimal('5.000')), MockNeuroGrasp(), MockRobotDriver(), SystemConfig(clock_cycle_sec=Decimal('0.001'), boot_delay_sec=Decimal('0.001'), scan_retry_delay_sec=Decimal('0.001'), task_wait_sec=Decimal('0.001'), safe_sum_limit_mm=Decimal('5.000')))
    xo.ctx.state = RobotState.SCANNING
    xo.run_cycle()
    xo.run_cycle()
    assert xo.ctx.state == RobotState.IDLE
    assert xo.ctx.target_coords is None


def test_verification_resets_fault_counter():
    xo = FactoryOrchestratorLambda(MockHaloSafe(), MockNeuroGrasp(), MockRobotDriver(), SystemConfig(clock_cycle_sec=Decimal('0.001'), boot_delay_sec=Decimal('0.001'), scan_retry_delay_sec=Decimal('0.001'), task_wait_sec=Decimal('0.001')))
    xo.ctx.state = RobotState.VERIFYING
    xo.ctx.fault_counter = 2
    xo.run_cycle()
    assert xo.ctx.state == RobotState.IDLE
    assert xo.ctx.fault_counter == 0


def test_telemetry_has_required_keys():
    xo = FactoryOrchestratorLambda(MockHaloSafe(), MockNeuroGrasp(), MockRobotDriver())
    data = xo.get_telemetry()
    assert data['schema_id'] == 'fo.telemetry'
    assert 'determinism_hash' in data
    assert data['state'] == 'BOOT'
