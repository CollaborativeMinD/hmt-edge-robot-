from decimal import Decimal
from src.factory_orchestrator_lambda import FactoryOrchestratorLambda, MockHaloSafe, MockNeuroGrasp, MockRobotDriver, RobotState, SystemConfig


def test_pace_escalation_path():
    driver = MockRobotDriver()
    xo = FactoryOrchestratorLambda(MockHaloSafe(), MockNeuroGrasp(), driver, SystemConfig(clock_cycle_sec=Decimal('0.001'), boot_delay_sec=Decimal('0.001'), scan_retry_delay_sec=Decimal('0.001'), task_wait_sec=Decimal('0.001')))
    xo.ctx.state = RobotState.FAULT
    xo.run_cycle()
    assert xo.ctx.state == RobotState.IDLE
    xo.ctx.state = RobotState.FAULT
    xo.run_cycle()
    assert driver.moves[-1] == (Decimal('0.000'), Decimal('0.000'), Decimal('0.000'))
    xo.ctx.state = RobotState.FAULT
    xo.run_cycle()
    assert xo.ctx.state == RobotState.BOOT
    xo.ctx.state = RobotState.FAULT
    xo.run_cycle()
    assert xo.ctx.state == RobotState.SHUTDOWN
    assert driver.estop_count == 1


def test_decimal_coordinate_quantization():
    driver = MockRobotDriver()
    vision = MockNeuroGrasp(coords=(Decimal('10.0004'), Decimal('20.0005'), Decimal('30.0006')))
    xo = FactoryOrchestratorLambda(MockHaloSafe(), vision, driver, SystemConfig(clock_cycle_sec=Decimal('0.001'), boot_delay_sec=Decimal('0.001'), scan_retry_delay_sec=Decimal('0.001'), task_wait_sec=Decimal('0.001')))
    xo.ctx.state = RobotState.SCANNING
    xo.run_cycle()
    assert xo.ctx.target_coords == (Decimal('10.000'), Decimal('20.001'), Decimal('30.001'))


def test_scan_none_holds_scanning_and_sets_alternate_lane():
    xo = FactoryOrchestratorLambda(MockHaloSafe(), MockNeuroGrasp(coords=None), MockRobotDriver(), SystemConfig(clock_cycle_sec=Decimal('0.001'), boot_delay_sec=Decimal('0.001'), scan_retry_delay_sec=Decimal('0.001'), task_wait_sec=Decimal('0.001')))
    xo.ctx.state = RobotState.SCANNING
    xo.run_cycle()
    assert xo.ctx.state == RobotState.SCANNING
    assert xo.ctx.pace_lane.value == 'ALTERNATE'


def test_boot_failure_routes_to_fault():
    class BadVision(MockNeuroGrasp):
        def health_check(self):
            return False
    xo = FactoryOrchestratorLambda(MockHaloSafe(), BadVision(), MockRobotDriver(), SystemConfig(clock_cycle_sec=Decimal('0.001'), boot_delay_sec=Decimal('0.001'), scan_retry_delay_sec=Decimal('0.001'), task_wait_sec=Decimal('0.001')))
    xo.ctx.state = RobotState.BOOT
    xo.run_cycle()
    assert xo.ctx.state == RobotState.FAULT


def test_determinism_hash_stable_for_same_state():
    xo = FactoryOrchestratorLambda(MockHaloSafe(), MockNeuroGrasp(), MockRobotDriver())
    a = xo.get_telemetry(message='a')
    b = xo.get_telemetry(message='b')
    assert a['determinism_hash'] == b['determinism_hash']
