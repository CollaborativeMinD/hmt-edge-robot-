from __future__ import annotations

from datetime import datetime, timezone
from decimal import Decimal, ROUND_HALF_UP
from enum import Enum
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

DECIMAL_QUANT = Decimal('0.001')


def q3(value: Decimal | str | float | int) -> Decimal:
    return Decimal(str(value)).quantize(DECIMAL_QUANT, rounding=ROUND_HALF_UP)


class RobotState(str, Enum):
    BOOT = 'BOOT'
    IDLE = 'IDLE'
    SCANNING = 'SCANNING'
    PLANNING = 'PLANNING'
    EXECUTING = 'EXECUTING'
    VERIFYING = 'VERIFYING'
    FAULT = 'FAULT'
    SHUTDOWN = 'SHUTDOWN'


class PaceLane(str, Enum):
    PRIMARY = 'PRIMARY'
    ALTERNATE = 'ALTERNATE'
    CONTINGENCY = 'CONTINGENCY'
    EMERGENCY = 'EMERGENCY'


class CoordinatePacket(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True)
    x_mm: Decimal
    y_mm: Decimal
    z_mm: Decimal

    @field_validator('x_mm', 'y_mm', 'z_mm', mode='before')
    @classmethod
    def to_decimal(cls, value):
        return q3(value)


class SystemConfigContract(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True, frozen=True)
    clock_cycle_sec: Decimal = Field(gt=Decimal('0'))
    boot_delay_sec: Decimal = Field(ge=Decimal('0'))
    scan_retry_delay_sec: Decimal = Field(ge=Decimal('0'))
    task_wait_sec: Decimal = Field(ge=Decimal('0'))
    max_retry_attempts: int = Field(ge=1, le=10)
    home_x_mm: Decimal
    home_y_mm: Decimal
    home_z_mm: Decimal
    safe_sum_limit_mm: Decimal = Field(gt=Decimal('0'))

    @field_validator('clock_cycle_sec', 'boot_delay_sec', 'scan_retry_delay_sec', 'task_wait_sec', 'home_x_mm', 'home_y_mm', 'home_z_mm', 'safe_sum_limit_mm', mode='before')
    @classmethod
    def quantize_decimal(cls, value):
        return q3(value)


class TelemetryContract(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True)
    schema_id: Literal['fo.telemetry'] = 'fo.telemetry'
    schema_version: Literal['1.0.0'] = '1.0.0'
    determinism_hash: str = Field(min_length=8)
    monotonic_seq: int = Field(ge=0)
    timestamp_utc: str
    state: RobotState
    pace_lane: PaceLane
    mission_active: bool
    fault_level: int = Field(ge=0)
    target_coords: CoordinatePacket | None = None
    safety_status: str
    message: str

    @field_validator('timestamp_utc')
    @classmethod
    def validate_timestamp(cls, value: str) -> str:
        datetime.fromisoformat(value.replace('Z', '+00:00'))
        return value


class GateResult(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True)
    gate_id: str
    status: Literal['PASS', 'FAIL', 'HOLD', 'ESCALATE', 'REJECT']
    criteria: list[str]
    fail_reasons: list[str]
    repair_required: bool
    escalation_required: bool


class ArtifactManifestEntry(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True)
    path: str
    sha256: str
    artifact_type: str
    purpose: str
    iteration_id: str
    timestamp_utc: str


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace('+00:00', 'Z')
