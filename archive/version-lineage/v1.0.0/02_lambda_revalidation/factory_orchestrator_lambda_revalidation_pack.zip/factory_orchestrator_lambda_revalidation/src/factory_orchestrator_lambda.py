from __future__ import annotations

import hashlib
from dataclasses import dataclass
from decimal import Decimal
from typing import Protocol

from src.contracts import CoordinatePacket, PaceLane, RobotState, SystemConfigContract, TelemetryContract, q3, utc_now


class SafetyProtocol(Protocol):
    def check_path(self, coords: tuple[Decimal, Decimal, Decimal]) -> tuple[bool, tuple[Decimal, Decimal, Decimal]]: ...
    def get_status(self) -> str: ...


class VisionProtocol(Protocol):
    def health_check(self) -> bool: ...
    def get_grasp_coordinates(self) -> tuple[Decimal, Decimal, Decimal] | None: ...


class DriverProtocol(Protocol):
    def move_to(self, coords: tuple[Decimal, Decimal, Decimal]) -> bool: ...
    def gripper_actuate(self, state: str) -> bool: ...
    def emergency_stop(self) -> None: ...


@dataclass(frozen=True)
class SystemConfig:
    clock_cycle_sec: Decimal = Decimal('0.100')
    boot_delay_sec: Decimal = Decimal('1.000')
    scan_retry_delay_sec: Decimal = Decimal('1.000')
    task_wait_sec: Decimal = Decimal('2.000')
    max_retry_attempts: int = 3
    home_coordinates: tuple[Decimal, Decimal, Decimal] = (Decimal('0.000'), Decimal('0.000'), Decimal('0.000'))
    safe_sum_limit_mm: Decimal = Decimal('100.000')

    def validate(self) -> SystemConfigContract:
        return SystemConfigContract.model_validate({
            'clock_cycle_sec': self.clock_cycle_sec,
            'boot_delay_sec': self.boot_delay_sec,
            'scan_retry_delay_sec': self.scan_retry_delay_sec,
            'task_wait_sec': self.task_wait_sec,
            'max_retry_attempts': self.max_retry_attempts,
            'home_x_mm': self.home_coordinates[0],
            'home_y_mm': self.home_coordinates[1],
            'home_z_mm': self.home_coordinates[2],
            'safe_sum_limit_mm': self.safe_sum_limit_mm,
        })


@dataclass
class MissionContext:
    state: RobotState = RobotState.BOOT
    target_coords: tuple[Decimal, Decimal, Decimal] | None = None
    fault_counter: int = 0
    mission_active: bool = True
    pace_lane: PaceLane = PaceLane.PRIMARY
    seq: int = 0


class MockHaloSafe:
    def __init__(self, safe_sum_limit_mm: Decimal = Decimal('100.000')) -> None:
        self.safe_sum_limit_mm = q3(safe_sum_limit_mm)

    def check_path(self, coords: tuple[Decimal, Decimal, Decimal]) -> tuple[bool, tuple[Decimal, Decimal, Decimal]]:
        total = q3(coords[0] + coords[1] + coords[2])
        return (total < self.safe_sum_limit_mm, tuple(q3(c) for c in coords))

    def get_status(self) -> str:
        return 'ONLINE'


class MockNeuroGrasp:
    def __init__(self, coords: tuple[Decimal, Decimal, Decimal] | None = (Decimal('10.000'), Decimal('20.000'), Decimal('30.000'))) -> None:
        self.coords = coords

    def health_check(self) -> bool:
        return True

    def get_grasp_coordinates(self) -> tuple[Decimal, Decimal, Decimal] | None:
        return self.coords


class MockRobotDriver:
    def __init__(self) -> None:
        self.moves: list[tuple[Decimal, Decimal, Decimal]] = []
        self.gripper_states: list[str] = []
        self.estop_count: int = 0

    def move_to(self, coords: tuple[Decimal, Decimal, Decimal]) -> bool:
        self.moves.append(tuple(q3(c) for c in coords))
        return True

    def gripper_actuate(self, state: str) -> bool:
        self.gripper_states.append(state)
        return True

    def emergency_stop(self) -> None:
        self.estop_count += 1


class FactoryOrchestratorLambda:
    def __init__(self, safety_sys: SafetyProtocol, vision_sys: VisionProtocol, hardware_sys: DriverProtocol, config: SystemConfig = SystemConfig()) -> None:
        self.cfg = config
        self.cfg.validate()
        self.safety = safety_sys
        self.vision = vision_sys
        self.hardware = hardware_sys
        self.ctx = MissionContext()

    def run_cycle(self) -> None:
        if self.ctx.state == RobotState.BOOT:
            self._handle_boot()
        elif self.ctx.state == RobotState.IDLE:
            self._handle_idle()
        elif self.ctx.state == RobotState.SCANNING:
            self._handle_scanning()
        elif self.ctx.state == RobotState.PLANNING:
            self._handle_planning()
        elif self.ctx.state == RobotState.EXECUTING:
            self._handle_execution()
        elif self.ctx.state == RobotState.VERIFYING:
            self._handle_verification()
        elif self.ctx.state == RobotState.FAULT:
            self._handle_pace_plan()
        elif self.ctx.state == RobotState.SHUTDOWN:
            self.ctx.mission_active = False
        else:
            self.ctx.state = RobotState.FAULT
        self.ctx.seq += 1

    def _handle_boot(self) -> None:
        if self.vision.health_check():
            self.ctx.state = RobotState.IDLE
            self.ctx.pace_lane = PaceLane.PRIMARY
        else:
            self.ctx.state = RobotState.FAULT

    def _handle_idle(self) -> None:
        self.ctx.state = RobotState.SCANNING
        self.ctx.pace_lane = PaceLane.PRIMARY

    def _handle_scanning(self) -> None:
        coords = self.vision.get_grasp_coordinates()
        if coords is None:
            self.ctx.pace_lane = PaceLane.ALTERNATE
            return
        packet = CoordinatePacket.model_validate({'x_mm': coords[0], 'y_mm': coords[1], 'z_mm': coords[2]})
        self.ctx.target_coords = (packet.x_mm, packet.y_mm, packet.z_mm)
        self.ctx.state = RobotState.PLANNING

    def _handle_planning(self) -> None:
        if not self.ctx.target_coords:
            self.ctx.state = RobotState.FAULT
            return
        is_safe, modified_coords = self.safety.check_path(self.ctx.target_coords)
        if is_safe:
            packet = CoordinatePacket.model_validate({'x_mm': modified_coords[0], 'y_mm': modified_coords[1], 'z_mm': modified_coords[2]})
            self.ctx.target_coords = (packet.x_mm, packet.y_mm, packet.z_mm)
            self.ctx.state = RobotState.EXECUTING
        else:
            self.ctx.target_coords = None
            self.ctx.state = RobotState.IDLE
            self.ctx.pace_lane = PaceLane.ALTERNATE

    def _handle_execution(self) -> None:
        if self.ctx.target_coords is None:
            self.ctx.state = RobotState.FAULT
            return
        self.hardware.move_to(self.ctx.target_coords)
        self.hardware.gripper_actuate('CLOSE')
        self.ctx.state = RobotState.VERIFYING

    def _handle_verification(self) -> None:
        self.ctx.state = RobotState.IDLE
        self.ctx.fault_counter = 0
        self.ctx.pace_lane = PaceLane.PRIMARY

    def _handle_pace_plan(self) -> None:
        self.ctx.fault_counter += 1
        if self.ctx.fault_counter == 1:
            self.ctx.pace_lane = PaceLane.PRIMARY
            self.ctx.state = RobotState.IDLE
        elif self.ctx.fault_counter == 2:
            self.ctx.pace_lane = PaceLane.ALTERNATE
            self.hardware.move_to(self.cfg.home_coordinates)
            self.ctx.state = RobotState.IDLE
        elif self.ctx.fault_counter == 3:
            self.ctx.pace_lane = PaceLane.CONTINGENCY
            self.ctx.state = RobotState.BOOT
        else:
            self.ctx.pace_lane = PaceLane.EMERGENCY
            self.hardware.emergency_stop()
            self.ctx.state = RobotState.SHUTDOWN

    def get_telemetry(self, message: str = 'heartbeat') -> dict:
        target = None
        if self.ctx.target_coords is not None:
            target = CoordinatePacket.model_validate({'x_mm': self.ctx.target_coords[0], 'y_mm': self.ctx.target_coords[1], 'z_mm': self.ctx.target_coords[2]})
        payload = {
            'schema_id': 'fo.telemetry',
            'schema_version': '1.0.0',
            'monotonic_seq': self.ctx.seq,
            'timestamp_utc': utc_now(),
            'state': self.ctx.state,
            'pace_lane': self.ctx.pace_lane,
            'mission_active': self.ctx.mission_active,
            'fault_level': self.ctx.fault_counter,
            'target_coords': target,
            'safety_status': self.safety.get_status(),
            'message': message,
        }
        core = f"{payload['schema_id']}|{payload['schema_version']}|{payload['monotonic_seq']}|{payload['state'].value}|{payload['pace_lane'].value}|{payload['fault_level']}|{payload['safety_status']}"
        payload['determinism_hash'] = hashlib.sha256(core.encode()).hexdigest()
        model = TelemetryContract.model_validate(payload)
        return model.model_dump(mode='json')
