from __future__ import annotations

from decimal import Decimal

from src.factory_orchestrator_lambda import FactoryOrchestratorLambda, MockHaloSafe, MockNeuroGrasp, MockRobotDriver, RobotState


def run_nominal_campaign() -> dict:
    xo = FactoryOrchestratorLambda(MockHaloSafe(), MockNeuroGrasp(), MockRobotDriver())
    timeline = []
    for _ in range(6):
        xo.run_cycle()
        timeline.append((xo.ctx.state.value, xo.ctx.pace_lane.value, xo.ctx.fault_counter))
    return {'final_state': xo.ctx.state.value, 'fault_counter': xo.ctx.fault_counter, 'timeline': timeline}


def run_fault_campaign() -> dict:
    driver = MockRobotDriver()
    xo = FactoryOrchestratorLambda(MockHaloSafe(), MockNeuroGrasp(), driver)
    states = []
    for _ in range(4):
        xo.ctx.state = RobotState.FAULT
        xo.run_cycle()
        states.append((xo.ctx.state.value, xo.ctx.pace_lane.value, xo.ctx.fault_counter, driver.estop_count))
    return {'fault_path': states, 'estop_count': driver.estop_count}


def campaign_metrics() -> dict:
    nominal = run_nominal_campaign()
    fault = run_fault_campaign()
    return {
        'FAST': {'passed': nominal['final_state'] == 'IDLE'},
        'CERT': {'passed': nominal['fault_counter'] == 0 and fault['estop_count'] == 1},
        'HOLDOUT': {'passed': fault['fault_path'][-1][0] == 'SHUTDOWN'},
        'REGRESSION': {'passed': len(nominal['timeline']) == 6},
        'nominal': nominal,
        'fault': fault,
    }
