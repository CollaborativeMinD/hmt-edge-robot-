# RTM.md - Factory Orchestrator Lambda Uplift

| Requirement ID | Requirement | Artifact | Verification Method | Status |
|---|---|---|---|---|
| FO-R1 | Orchestrator shall execute deterministic FSM transitions. | src/factory_orchestrator_lambda.py | pytest + notebook SIL replay | PASS |
| FO-R2 | Coordinate decision seams shall be quantized to 0.001 mm precision. | src/contracts.py, src/factory_orchestrator_lambda.py | pytest decimal quantization test | PASS |
| FO-R3 | Unsafe path plans shall be rejected before execution. | src/factory_orchestrator_lambda.py | pytest safety rejection test | PASS |
| FO-R4 | Persistent faults shall escalate through Primary, Alternate, Contingency, Emergency. | src/factory_orchestrator_lambda.py | pytest pace escalation test | PASS |
| FO-R5 | Telemetry shall be evidence-grade and contract-validated. | src/contracts.py | pytest telemetry schema test + notebook | PASS |
| FO-R6 | Revalidation shall produce executable notebook evidence. | runs/FO-001/notebooks/iteration_001.executed.ipynb | executed notebook | PASS |
