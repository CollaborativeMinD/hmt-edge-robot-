# ICD_FactoryOrchestrator.Cell.MotionAssessment.md

## ICD-1 Header

| Field | Value |
|---|---|
| ICD_ID | ICD-FactoryOrchestrator.Cell.MotionAssessment |
| ICD_NAME | Motion Assessment Interface |
| ICD_STATUS | CERTIFIED |
| PRODUCER | Vision/Safety Stack |
| CONSUMER | FactoryOrchestrator |
| INTERFACE_TYPE | DATA |
| DIRECTION | PRODUCER→CONSUMER |
| TRANSPORT | In-process deterministic call |
| ENCODING | Pydantic model |
| SCHEMA_ID | fo.telemetry |
| SCHEMA_VERSION | 1.0.0 |
| SECURITY_CLASS | INTERNAL |
| OWNERSHIP | JOINT |
| CHANGE_CONTROL | Lambda uplift pack |

## ICD-2 Data Dictionary

| FieldName | Direction | Type | Units | Required | Constraints | Default | Example | Notes |
|---|---|---|---|---|---|---|---|---|
| x_mm | IN | decimal | mm | Y | quantized 0.001 | n/a | 10.000 | target x |
| y_mm | IN | decimal | mm | Y | quantized 0.001 | n/a | 20.000 | target y |
| z_mm | IN | decimal | mm | Y | quantized 0.001 | n/a | 30.000 | target z |
| schema_id | OUT | string | none | Y | non-empty | n/a | fo.telemetry | determinism field |
| schema_version | OUT | string | none | Y | semver | n/a | 1.0.0 | determinism field |
| determinism_hash | OUT | string | none | Y | sha256 hex | n/a | ... | determinism field |
| monotonic_seq | OUT | int64 | none | Y | >=0 | 0 | 4 | determinism field |
| timestamp_utc | OUT | string | ISO-8601 | Y | valid datetime | n/a | 2026-03-28T00:00:00Z | determinism field |

## ICD-3 Timing & Ordering Contract

| Parameter | Value | Notes |
|---|---|---|
| DELIVERY_MODE | EXACTLY_ONCE | per cycle |
| ORDERING | SEQ_ENFORCED | monotonic_seq |
| MAX_LATENCY_MS | 100 | one orchestrator cycle |
| MAX_JITTER_MS | 0 | SIL deterministic |
| UPDATE_RATE_HZ | 10 | nominal cycle |
| BURST_MAX | 1 | one packet per cycle |
| TIMEOUT_MS | 200 | beyond two cycles is fail |
| CLOCK_SOURCE | CONSUMER | local execution clock |
| STALENESS_MS | 200 | stale beyond two cycles |
| RETRY_POLICY | none | no hidden retry |

### 3.1 Late / missing / out-of-order handling

| Condition | Detect | Classify | Consumer Action | Evidence |
|---|---|---|---|---|
| LATE | packet arrives after 100 ms budget | DEGRADED | hold execution, log, remain non-executing | notebook SIL campaign |
| MISSING | no packet for 200 ms | FAIL | route to FAULT | pytest + notebook |
| OUT_OF_ORDER | monotonic_seq decreases | FAIL | reject packet | telemetry contract |
| STALE | age > 200 ms | FAIL | route to FAULT | notebook review |

## ICD-4 Failure Semantics

| Failure | Trigger | Detection Method | Producer Action | Consumer Action | Safe State | Recovery | Evidence |
|---|---|---|---|---|---|---|---|
| E_CONSTRAINT_VIOLATION | non-quantized or invalid coords | Pydantic validator | reject packet | route to FAULT or IDLE depending seam | IDLE/FAULT | reacquire target | pytest |
| E_TIMEOUT | timing budget exceeded | cycle budget monitor | n/a | route to FAULT | FAULT | PACE escalation | notebook |
| E_STALE_DATA | stale packet used | timestamp check | n/a | reject packet | FAULT | rescan | notebook |

## ICD-5 PACE Behavior

| Lane | Mechanism | Trigger | Detection | Expected Degradation | Recovery Procedure | Verification Evidence |
|---|---|---|---|---|---|---|
| Primary | normal scan-plan-execute-verify | healthy packet and safe path | health check + validator | none | continue loop | pytest nominal |
| Alternate | hold/rescan or home retreat | no target or second fault | scan none / fault counter 2 | slower throughput | rescan or home retreat | pytest + notebook |
| Contingency | reboot logic path | third persistent fault | fault counter 3 | software restart | BOOT reentry | pytest |
| Emergency | hardware stop | fourth persistent fault | fault counter >=4 | full halt | operator reset | pytest + CERT |
