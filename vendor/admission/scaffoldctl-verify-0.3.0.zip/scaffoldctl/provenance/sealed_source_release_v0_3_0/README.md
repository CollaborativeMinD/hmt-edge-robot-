# Sealed Source Release v0.3.0

This directory preserves the incoming `scaffoldctl` v0.3.0 closeout record. Its manifests and
checksums describe the original sealed source-release layout, including paths that were normalized
after intake. They do not attest to the current operational tree.

- `closeout_evidence/` contains the immutable receipts, manifest, checksum ledger, and DuckDB seal.
- `distributions/` contains the wheel and source distribution named by that closeout evidence.
- Wheel SHA-256: `8462f8af16f6a5612572a35c8ec6615de9235198d3116bdf5ce623f48e249159`
- Source distribution SHA-256: `24cdc01c268fe5cb5dbca13eada05528791479c6a9e3aa50eddb041904721023`

Current-tree V&V and manifests must be generated independently. Never reinterpret this historical
seal as approval for later edits, MCP+ integration, or external promotion.
